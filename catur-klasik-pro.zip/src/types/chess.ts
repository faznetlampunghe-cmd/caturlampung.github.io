export type PieceType = 'p' | 'n' | 'b' | 'r' | 'q' | 'k';
export type PieceColor = 'w' | 'b';

export interface Piece {
  type: PieceType;
  color: PieceColor;
}

export type Board = (Piece | null)[][]; // 8x8: [row 0-7][col 0-7], row 0 is rank 8, row 7 is rank 1

export interface SquareCoord {
  row: number; // 0 to 7
  col: number; // 0 to 7
}

export interface Move {
  from: SquareCoord;
  to: SquareCoord;
  piece: Piece;
  captured?: Piece | null;
  promotion?: PieceType;
  isCastling?: 'kingside' | 'queenside';
  isEnPassant?: boolean;
  san?: string;
}

export interface CastlingRights {
  wK: boolean; // White can castle kingside
  wQ: boolean; // White can castle queenside
  bK: boolean; // Black can castle kingside
  bQ: boolean; // Black can castle queenside
}

export interface GameState {
  board: Board;
  turn: PieceColor;
  castling: CastlingRights;
  enPassantTarget: SquareCoord | null; // Square that can be captured en passant
  halfmoveClock: number; // For 50-move rule
  fullmoveNumber: number;
  history: Move[];
  isCheck: boolean;
  isCheckmate: boolean;
  isStalemate: boolean;
  isDrawFiftyMoves: boolean;
  isDrawRepetition: boolean;
  isDrawInsufficientMaterial: boolean;
  isGameOver: boolean;
  isResigned: boolean;
  resignedBy: PieceColor | null;
  winner: PieceColor | 'draw' | null;
  capturedPieces: {
    w: Piece[]; // Captured by white (black pieces)
    b: Piece[]; // Captured by black (white pieces)
  };
  positionHistory: string[]; // For threefold repetition
}

export type Difficulty = 'easy' | 'medium' | 'hard';

export type GameMode = 'ai-white' | 'ai-black' | 'pass-and-play';

export type TimeControlOption = 0 | 180 | 300 | 600 | 900; // seconds (0 = unlimited)
