import React from 'react';

interface EvalBarProps {
  score: number; // Centipawns (+ score favors white, - favors black)
}

export const EvalBar: React.FC<EvalBarProps> = ({ score }) => {
  // Clamp score between -1000 and 1000 centipawns (+10 to -10 pawns)
  const clamped = Math.max(-1000, Math.min(1000, score));
  // Convert to percentage for White: 50% is equal, 100% is completely white winning, 0% is black winning
  const whitePercent = 50 + (clamped / 1000) * 45;

  // Human readable pawn advantage
  const pawnVal = (score / 100).toFixed(1);
  const displayScore = score > 0 ? `+${pawnVal}` : pawnVal;

  return (
    <div className="flex items-center gap-2 text-xs">
      <span className="text-[11px] font-semibold text-stone-400">Eval:</span>
      <div className="relative flex-1 h-2.5 bg-[#1a1410] rounded-full overflow-hidden border border-[#442c1c]">
        {/* White evaluation fill */}
        <div
          className="h-full bg-gradient-to-r from-amber-200 to-amber-100 transition-all duration-300"
          style={{ width: `${whitePercent}%` }}
        />
        {/* Center line marker */}
        <div className="absolute top-0 bottom-0 left-1/2 w-0.5 bg-stone-500/60 -translate-x-1/2" />
      </div>
      <span className="text-[11px] font-mono font-semibold text-stone-300 w-10 text-right">
        {displayScore}
      </span>
    </div>
  );
};
