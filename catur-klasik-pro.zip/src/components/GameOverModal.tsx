import React from 'react';
import { GameState, PieceColor } from '../types/chess';
import { Trophy, ShieldAlert, RotateCcw, Share2, Check } from 'lucide-react';

interface GameOverModalProps {
  gameState: GameState;
  playerColor: PieceColor;
  gameMode: string;
  onRestart: () => void;
  onExportPGN: () => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  gameState,
  playerColor,
  gameMode,
  onRestart,
  onExportPGN,
}) => {
  const [copied, setCopied] = React.useState(false);
  const isPassAndPlay = gameMode === 'pass-and-play';

  const getTitleAndSubtitle = () => {
    if (gameState.isResigned) {
      if (isPassAndPlay) {
        const surrenderedSide = gameState.resignedBy === 'w' ? 'Putih' : 'Hitam';
        const victoriousSide = gameState.winner === 'w' ? 'Putih' : 'Hitam';
        return {
          title: `Pemain ${surrenderedSide} Menyerah — ${victoriousSide} Menang`,
          subtitle: `Pemain ${surrenderedSide} memutuskan untuk menyerah. Selamat untuk Pemain ${victoriousSide}!`,
          isWin: true,
          isDraw: false,
        };
      }
      return {
        title: 'Anda Menyerah — Komputer Menang',
        subtitle: 'Permainan telah diakhiri karena Anda memutuskan untuk menyerah.',
        isWin: false,
        isDraw: false,
      };
    }

    if (gameState.isCheckmate) {
      const winnerName = gameState.winner === 'w' ? 'Putih' : 'Hitam';
      const isPlayerWinner = isPassAndPlay ? true : gameState.winner === playerColor;
      return {
        title: isPassAndPlay
          ? `Skakmat! Pemain ${winnerName} Menang`
          : isPlayerWinner
          ? 'Skakmat! Anda Menang Cemerlang'
          : 'Skakmat! Komputer Menang',
        subtitle: isPassAndPlay
          ? `Kemenangan taktis yang gemilang untuk Pemain ${winnerName}!`
          : isPlayerWinner
          ? 'Selamat atas kemenangan cemerlang Anda menundukkan AI catur!'
          : 'Komputer berhasil mengeksekusi skakmat. Evaluasi taktik dan coba kembali!',
        isWin: isPlayerWinner,
        isDraw: false,
      };
    }

    if (gameState.isStalemate) {
      return {
        title: 'Remis: Stalemate (Pat)',
        subtitle: 'Tidak ada langkah legal yang dapat dijalankan dan Raja tidak dalam posisi skak.',
        isWin: false,
        isDraw: true,
      };
    }

    if (gameState.isDrawInsufficientMaterial) {
      return {
        title: 'Remis: Materi Bidak Tidak Cukup',
        subtitle: 'Kedua pemain tidak lagi memiliki sisa materi bidak yang cukup untuk memaksakan skakmat (K vs K, K+B vs K, K+N vs K).',
        isWin: false,
        isDraw: true,
      };
    }

    if (gameState.isDrawFiftyMoves) {
      return {
        title: 'Remis: Aturan 50 Langkah',
        subtitle: '50 langkah berturut-turut telah lewat tanpa ada pion yang digerakkan atau bidak yang dimakan.',
        isWin: false,
        isDraw: true,
      };
    }

    if (gameState.isDrawRepetition) {
      return {
        title: 'Remis: Tiga Kali Pengulangan',
        subtitle: 'Posisi papan yang identik telah terjadi sebanyak tiga kali (Threefold Repetition).',
        isWin: false,
        isDraw: true,
      };
    }

    return {
      title: 'Permainan Selesai',
      subtitle: 'Hasil akhir telah ditentukan.',
      isWin: false,
      isDraw: false,
    };
  };

  const info = getTitleAndSubtitle();

  const handleShare = () => {
    onExportPGN();
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-fade-in">
      <div className="bg-gradient-to-b from-[#2a1b12] to-[#1a100a] border-2 border-[#6d4629] rounded-2xl p-6 sm:p-8 shadow-2xl max-w-md w-full text-center relative overflow-hidden">
        {/* Decorative corner highlights */}
        <div className="absolute top-0 left-0 w-16 h-16 bg-[#c29853]/10 rounded-br-full pointer-events-none" />
        <div className="absolute top-0 right-0 w-16 h-16 bg-[#c29853]/10 rounded-bl-full pointer-events-none" />

        {/* Icon Header */}
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-[#3f2819] border-2 border-[#7a4c2b] text-amber-300 mb-4 shadow-lg">
          {info.isWin ? (
            <Trophy className="w-8 h-8 text-amber-400 animate-bounce" />
          ) : (
            <ShieldAlert className="w-8 h-8 text-stone-300" />
          )}
        </div>

        <h2 className="font-serif text-2xl font-bold text-[#f4eee4] tracking-tight mb-2">
          {info.title}
        </h2>
        <p className="text-xs sm:text-sm text-stone-300/90 leading-relaxed mb-6 px-2">
          {info.subtitle}
        </p>

        {/* Game summary stats */}
        <div className="grid grid-cols-2 gap-3 p-3 bg-[#1e130c] rounded-xl border border-[#442c1c] mb-6 text-xs text-stone-300">
          <div>
            <span className="text-stone-400 block mb-0.5">Total Langkah</span>
            <span className="font-mono text-sm font-bold text-amber-200">
              {gameState.history.length}
            </span>
          </div>
          <div>
            <span className="text-stone-400 block mb-0.5">Bidak Termakan</span>
            <span className="font-mono text-sm font-bold text-amber-200">
              {gameState.capturedPieces.w.length + gameState.capturedPieces.b.length}
            </span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-3">
          <button
            onClick={onRestart}
            className="flex-1 flex items-center justify-center gap-2 px-5 py-2.5 bg-gradient-to-r from-[#9c6339] to-[#b37747] hover:from-[#b37747] hover:to-[#c68958] text-white text-xs sm:text-sm font-semibold rounded-xl shadow-lg transition-all transform active:scale-95 cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Mulai Pertandingan Baru</span>
          </button>

          <button
            onClick={handleShare}
            className="flex items-center justify-center gap-2 px-4 py-2.5 bg-[#321f14] hover:bg-[#442a1b] text-stone-300 hover:text-amber-200 border border-[#52331f] text-xs sm:text-sm font-medium rounded-xl transition-colors cursor-pointer"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Share2 className="w-4 h-4" />}
            <span>Unduh PGN</span>
          </button>
        </div>
      </div>
    </div>
  );
};
