import React from 'react';
import { Piece, PieceColor } from '../types/chess';
import { CapturedPieces } from './CapturedPieces';
import { Bot, User, Clock } from 'lucide-react';

interface PlayerCardProps {
  name: string;
  isAI: boolean;
  color: PieceColor;
  isTurn: boolean;
  capturedPieces: Piece[];
  materialAdvantage: number;
  timeRemaining: number | null; // seconds or null for unlimited
}

export const PlayerCard: React.FC<PlayerCardProps> = ({
  name,
  isAI,
  color,
  isTurn,
  capturedPieces,
  materialAdvantage,
  timeRemaining,
}) => {
  const isWhite = color === 'w';

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div
      className={`flex items-center justify-between p-2.5 sm:p-3 rounded-xl border transition-all ${
        isTurn
          ? 'bg-[#2a1b12] border-amber-500/80 shadow-md ring-1 ring-amber-500/30'
          : 'bg-[#1a120c]/90 border-[#3d2719]'
      }`}
    >
      {/* Left: Avatar, Name & Captured Pieces */}
      <div className="flex items-center gap-3">
        <div
          className={`w-9 h-9 sm:w-10 sm:h-10 rounded-lg flex items-center justify-center border ${
            isWhite
              ? 'bg-amber-100/90 text-stone-900 border-amber-200'
              : 'bg-[#150f0b] text-amber-100 border-[#472d1a]'
          } shadow-sm`}
        >
          {isAI ? (
            <Bot className="w-5 h-5" />
          ) : (
            <User className="w-5 h-5" />
          )}
        </div>

        <div>
          <div className="flex items-center gap-2">
            <span className="font-serif text-xs sm:text-sm font-bold text-[#f2e6d6]">
              {name}
            </span>
            <span
              className={`text-[10px] font-semibold uppercase px-1.5 py-0.5 rounded ${
                isWhite
                  ? 'bg-amber-200/20 text-amber-200 border border-amber-400/30'
                  : 'bg-stone-800 text-stone-300 border border-stone-700'
              }`}
            >
              {isWhite ? 'Putih' : 'Hitam'}
            </span>
            {isTurn && (
              <span className="text-[10px] text-emerald-400 font-medium animate-pulse">
                • Giliran
              </span>
            )}
          </div>

          <div className="mt-1">
            <CapturedPieces
              pieces={capturedPieces}
              color={color}
              materialAdvantage={materialAdvantage}
            />
          </div>
        </div>
      </div>

      {/* Right: Clock (if enabled) */}
      {timeRemaining !== null && (
        <div
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border font-mono text-xs sm:text-sm font-bold ${
            isTurn
              ? timeRemaining <= 30
                ? 'bg-rose-950/80 text-rose-300 border-rose-600 animate-pulse'
                : 'bg-[#3b2416] text-amber-200 border-amber-600/40'
              : 'bg-[#1f140e] text-stone-400 border-[#382315]'
          }`}
        >
          <Clock className="w-3.5 h-3.5" />
          <span>{formatTime(timeRemaining)}</span>
        </div>
      )}
    </div>
  );
};
