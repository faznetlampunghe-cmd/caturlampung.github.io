import React from 'react';
import { Difficulty, GameMode, TimeControlOption } from '../types/chess';
import {
  RotateCcw,
  Undo2,
  Volume2,
  VolumeX,
  Lightbulb,
  Flag,
  FileCode2,
} from 'lucide-react';

interface GameControlsProps {
  difficulty: Difficulty;
  onDifficultyChange: (diff: Difficulty) => void;
  gameMode: GameMode;
  onGameModeChange: (mode: GameMode) => void;
  timeControl: TimeControlOption;
  onTimeControlChange: (tc: TimeControlOption) => void;
  onUndo: () => void;
  canUndo: boolean;
  onFlip: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
  onGetHint: () => void;
  isHintLoading: boolean;
  onDownloadHtml: () => void;
  onResign: () => void;
  isGameOver: boolean;
  isThinking: boolean;
}

export const GameControls: React.FC<GameControlsProps> = ({
  difficulty,
  onDifficultyChange,
  gameMode,
  onGameModeChange,
  timeControl,
  onTimeControlChange,
  onUndo,
  canUndo,
  onFlip,
  isMuted,
  onToggleMute,
  onGetHint,
  isHintLoading,
  onDownloadHtml,
  onResign,
  isGameOver,
  isThinking,
}) => {
  return (
    <div className="flex flex-col gap-3.5 p-4 bg-[#1e1510]/90 rounded-xl border border-[#442c1c] shadow-lg text-xs text-stone-300">
      {/* Primary Action Strip: Prominent Menyerah & Batal Langkah */}
      <div className="grid grid-cols-2 gap-2.5 pb-3 border-b border-[#3b2518]">
        {/* Undo Move Button */}
        <button
          onClick={onUndo}
          disabled={!canUndo || isThinking}
          className="flex items-center justify-center gap-2 py-2.5 px-3 bg-[#2d1d13] hover:bg-[#3f291a] disabled:opacity-40 disabled:pointer-events-none text-stone-200 rounded-xl border border-[#4d3220] transition-all cursor-pointer font-semibold shadow-sm"
          title="Batalkan Langkah Sebelumnya"
        >
          <Undo2 className="w-4 h-4 text-amber-400" />
          <span>Batal Langkah</span>
        </button>

        {/* Prominent Resign Button (Menyerah) */}
        <button
          onClick={onResign}
          disabled={isGameOver || isThinking}
          className="flex items-center justify-center gap-2 py-2.5 px-3 bg-gradient-to-r from-[#441a1a] to-[#592323] hover:from-[#592323] hover:to-[#6d2b2b] disabled:opacity-35 disabled:pointer-events-none text-rose-200 rounded-xl border border-rose-800/60 transition-all font-semibold shadow-sm cursor-pointer"
          title="Menyerah dan akhiri permainan saat ini"
        >
          <Flag className="w-4 h-4 text-rose-400" />
          <span>Menyerah</span>
        </button>
      </div>

      {/* Row 2: Mode & Difficulty Selectors */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {/* Mode Selector */}
        <div>
          <label className="block text-[11px] font-semibold text-stone-400 uppercase tracking-wider mb-1">
            Mode Permainan
          </label>
          <select
            value={gameMode}
            disabled={isThinking}
            onChange={e => onGameModeChange(e.target.value as GameMode)}
            className="w-full px-2.5 py-1.5 bg-[#2b1b11] border border-[#4d3220] disabled:opacity-40 rounded-lg text-stone-200 focus:outline-none focus:border-amber-500 font-medium cursor-pointer"
          >
            <option value="ai-white">Pemain (Putih) vs AI (Hitam)</option>
            <option value="ai-black">Pemain (Hitam) vs AI (Putih)</option>
            <option value="pass-and-play">2 Pemain Lokal (Gantian)</option>
          </select>
        </div>

        {/* Difficulty Selector */}
        <div>
          <label className="block text-[11px] font-semibold text-stone-400 uppercase tracking-wider mb-1">
            Tingkat Kesulitan AI
          </label>
          <select
            value={difficulty}
            disabled={isThinking}
            onChange={e => onDifficultyChange(e.target.value as Difficulty)}
            className="w-full px-2.5 py-1.5 bg-[#2b1b11] border border-[#4d3220] disabled:opacity-40 rounded-lg text-stone-200 focus:outline-none focus:border-amber-500 font-medium cursor-pointer"
          >
            <option value="easy">Mudah (Depth 1)</option>
            <option value="medium">Menengah (Depth 3 Minimax)</option>
            <option value="hard">Sulit (Depth 4 + Taktikal)</option>
          </select>
        </div>
      </div>

      {/* Row 3: Jam Catur (Time control) */}
      <div>
        <label className="block text-[11px] font-semibold text-stone-400 uppercase tracking-wider mb-1">
          Jam Catur (Waktu Berpikir)
        </label>
        <div className="grid grid-cols-4 gap-1.5">
          {[
            { label: 'Bebas', val: 0 },
            { label: '3 Mnt', val: 180 },
            { label: '10 Mnt', val: 600 },
            { label: '15 Mnt', val: 900 },
          ].map(tc => (
            <button
              key={tc.val}
              disabled={isThinking}
              onClick={() => onTimeControlChange(tc.val as TimeControlOption)}
              className={`py-1.5 px-2 text-[11px] font-semibold rounded-lg border transition-all disabled:opacity-40 ${
                timeControl === tc.val
                  ? 'bg-amber-700/50 border-amber-500 text-amber-200 shadow-sm'
                  : 'bg-[#2b1b11] border-[#442c1c] text-stone-400 hover:text-stone-200 hover:bg-[#382316]'
              }`}
            >
              {tc.label}
            </button>
          ))}
        </div>
      </div>

      {/* Row 4: Utility Buttons (Flip, Hint, Sound) */}
      <div className="grid grid-cols-3 gap-2 pt-1 border-t border-[#3b2518]">
        {/* Flip Board */}
        <button
          onClick={onFlip}
          disabled={isThinking}
          className="flex items-center justify-center gap-1.5 py-2 px-2.5 bg-[#2c1c12] hover:bg-[#3d2719] disabled:opacity-40 disabled:pointer-events-none text-stone-200 rounded-lg border border-[#472d1c] transition-all cursor-pointer font-medium"
          title="Balik Orientasi Papan Catur"
        >
          <RotateCcw className="w-3.5 h-3.5 text-amber-400" />
          <span>Balik</span>
        </button>

        {/* Hint */}
        <button
          onClick={onGetHint}
          disabled={isGameOver || isThinking || isHintLoading}
          className="flex items-center justify-center gap-1.5 py-2 px-2.5 bg-[#2c1c12] hover:bg-[#3d2719] disabled:opacity-40 disabled:pointer-events-none text-stone-200 rounded-lg border border-[#472d1c] transition-all cursor-pointer font-medium"
          title="Dapatkan Rekomendasi Langkah Terbaik dari AI"
        >
          <Lightbulb className="w-3.5 h-3.5 text-yellow-400" />
          <span>{isHintLoading ? '...' : 'Petunjuk'}</span>
        </button>

        {/* Sound Toggle */}
        <button
          onClick={onToggleMute}
          className="flex items-center justify-center gap-1.5 py-2 px-2.5 bg-[#2c1c12] hover:bg-[#3d2719] text-stone-200 rounded-lg border border-[#472d1c] transition-all cursor-pointer font-medium"
          title={isMuted ? 'Nyalakan Efek Suara' : 'Bisukan Suara'}
        >
          {isMuted ? (
            <>
              <VolumeX className="w-3.5 h-3.5 text-stone-400" />
              <span>Bisu</span>
            </>
          ) : (
            <>
              <Volume2 className="w-3.5 h-3.5 text-amber-400" />
              <span>Suara</span>
            </>
          )}
        </button>
      </div>

      {/* Row 5: Standalone Single-File HTML Download */}
      <div className="pt-1 border-t border-[#3b2518]">
        <button
          onClick={onDownloadHtml}
          className="w-full flex items-center justify-center gap-2 py-2 px-3 bg-emerald-900/60 hover:bg-emerald-800/80 text-emerald-200 border border-emerald-700/50 rounded-lg transition-all font-semibold cursor-pointer"
          title="Unduh seluruh game dalam 1 file .html yang dapat dibuka tanpa internet"
        >
          <FileCode2 className="w-4 h-4 text-emerald-400" />
          <span>Unduh File Game HTML Mandiri (Offline)</span>
        </button>
      </div>
    </div>
  );
};
