import React from 'react';
import { X, Cpu, Download, ShieldCheck, BookOpen, Layers } from 'lucide-react';

interface InfoModalProps {
  onClose: () => void;
  onDownloadHtml: () => void;
}

export const InfoModal: React.FC<InfoModalProps> = ({ onClose, onDownloadHtml }) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-fade-in">
      <div className="bg-[#21160f] border-2 border-[#5c3a21] rounded-2xl max-w-2xl w-full max-h-[88vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-[#2b1b11] border-b border-[#472d1a]">
          <div className="flex items-center gap-2.5">
            <BookOpen className="w-5 h-5 text-amber-400" />
            <h2 className="font-serif text-lg font-bold text-[#f5ecd8]">
              Tentang Catur Klasik Pro & Panduan Offline
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-stone-400 hover:text-white hover:bg-[#3d2718] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-6 text-xs sm:text-sm text-stone-300 leading-relaxed scrollbar-thin scrollbar-thumb-[#452b1b]">
          {/* Section 1: AI Transparency */}
          <div className="p-4 bg-[#1a110a] rounded-xl border border-[#3b2415]">
            <div className="flex items-center gap-2 mb-2">
              <Cpu className="w-4 h-4 text-amber-400" />
              <h3 className="font-semibold text-amber-200 text-sm">
                Arsitektur AI Catur Lokal (Tanpa Cloud/Server)
              </h3>
            </div>
            <p className="text-stone-300/90 mb-2">
              Permainan ini ditenagai oleh <strong>mesin catur JavaScript lokal</strong> berbasis algoritma{' '}
              <strong className="text-amber-100">Minimax dengan Alpha-Beta Pruning</strong> dan tabel nilai posisi bidak{' '}
              <em>(Piece-Square Tables / PST)</em>.
            </p>
            <ul className="list-disc pl-5 space-y-1 text-stone-400 text-xs">
              <li>
                <strong className="text-stone-200">Mudah (Depth 1):</strong> Evaluasi langkah cepat dengan toleransi variasi manusiawi, cocok untuk pemula.
              </li>
              <li>
                <strong className="text-stone-200">Menengah (Depth 3):</strong> Menghitung hingga 3 langkah ke depan dengan pemangkasan alpha-beta dan posisi bidak strategis.
              </li>
              <li>
                <strong className="text-stone-200">Sulit (Depth 4 + Quiescence):</strong> Analisis mendalam hingga 4 langkah ke depan dengan pengurutan langkah MVV-LVA serta penyelesaian benturan bidak (tactical quiescence).
              </li>
            </ul>
            <p className="mt-2 text-[11px] text-amber-400/80 italic">
              Catatan: AI ini tidak mengklaim memiliki IQ 100% atau tidak pernah kalah. Kekuatan AI sepenuhnya ditentukan oleh kedalaman pencarian matematis dan tabel evaluasi lokal.
            </p>
          </div>

          {/* Section 2: How to run offline */}
          <div className="p-4 bg-[#1a110a] rounded-xl border border-[#3b2415]">
            <div className="flex items-center gap-2 mb-2">
              <Download className="w-4 h-4 text-emerald-400" />
              <h3 className="font-semibold text-emerald-200 text-sm">
                Cara Menjalankan 100% Tanpa Internet (Offline)
              </h3>
            </div>
            <p className="text-stone-300/90 mb-3">
              Anda dapat mengunduh berkas permainan sebagai <strong>satu berkas HTML mandiri</strong>. Berkas ini berisi seluruh kode logika, grafis bidak SVG, mesin kecerdasan buatan, dan efek suara sintetis tanpa membutuhkan koneksi internet atau server sama sekali.
            </p>
            <button
              onClick={() => {
                onDownloadHtml();
              }}
              className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-800 hover:bg-emerald-700 text-white rounded-lg font-medium text-xs shadow transition-all cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Unduh Berkas HTML Mandiri (.html)</span>
            </button>
          </div>

          {/* Section 3: Standard Rules */}
          <div className="p-4 bg-[#1a110a] rounded-xl border border-[#3b2415]">
            <div className="flex items-center gap-2 mb-2">
              <ShieldCheck className="w-4 h-4 text-amber-400" />
              <h3 className="font-semibold text-amber-200 text-sm">
                Kepatuhan Aturan Standar FIDE
              </h3>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-stone-300">
              <div className="flex items-start gap-1.5">
                <Layers className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                <span><strong>Rokade Resmi:</strong> Kingside (O-O) & Queenside (O-O-O) dengan verifikasi petak tidak terancam.</span>
              </div>
              <div className="flex items-start gap-1.5">
                <Layers className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                <span><strong>En Passant:</strong> Memakan pion lawan yang maju 2 petak seketika pada giliran berikutnya.</span>
              </div>
              <div className="flex items-start gap-1.5">
                <Layers className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                <span><strong>Promosi Pion:</strong> Pilihan menjadi Menteri, Benteng, Gajah, atau Kuda saat mencapai baris akhir.</span>
              </div>
              <div className="flex items-start gap-1.5">
                <Layers className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                <span><strong>Deteksi Remis Otomatis:</strong> Stalemate (Pat), aturan 50 langkah, 3 kali pengulangan, dan materi bidak tidak cukup.</span>
              </div>
              <div className="flex items-start gap-1.5 sm:col-span-2">
                <Layers className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                <span><strong>Mode Dua Pemain Satu Perangkat:</strong> Main berdua bersama teman secara bergantian di satu layar dengan jam catur dan fitur balik papan.</span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-[#26180f] border-t border-[#472d1a] flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-[#422918] hover:bg-[#563620] text-stone-200 text-xs font-semibold rounded-lg transition-colors cursor-pointer"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
