import React, { useState } from 'react';
import { Board, Move, PieceColor, SquareCoord } from '../types/chess';
import { ChessPiece } from './ChessPiece';

interface ChessBoardProps {
  board: Board;
  turn: PieceColor;
  orientation: PieceColor; // 'w' means White on bottom, 'b' means Black on bottom
  selectedSquare: SquareCoord | null;
  legalMoves: Move[];
  lastMove: Move | null;
  isCheck: boolean;
  onSquareClick: (square: SquareCoord) => void;
  onPieceDrop: (from: SquareCoord, to: SquareCoord) => void;
  isThinking: boolean;
  disabled?: boolean;
}

export const ChessBoard: React.FC<ChessBoardProps> = ({
  board,
  turn,
  orientation,
  selectedSquare,
  legalMoves,
  lastMove,
  isCheck,
  onSquareClick,
  onPieceDrop,
  isThinking,
  disabled = false,
}) => {
  const [draggedCoord, setDraggedCoord] = useState<SquareCoord | null>(null);

  // Files and ranks for coordinates display
  const files = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'];
  const ranks = ['8', '7', '6', '5', '4', '3', '2', '1'];

  const displayedFiles = orientation === 'w' ? files : [...files].reverse();
  const displayedRanks = orientation === 'w' ? ranks : [...ranks].reverse();

  // Helper to map visual row/col (0 to 7) to actual board board[r][c]
  const getBoardCoord = (displayRow: number, displayCol: number): SquareCoord => {
    const row = orientation === 'w' ? displayRow : 7 - displayRow;
    const col = orientation === 'w' ? displayCol : 7 - displayCol;
    return { row, col };
  };

  const isSelected = (r: number, c: number) => {
    return selectedSquare?.row === r && selectedSquare?.col === c;
  };

  const isLastMoveSquare = (r: number, c: number) => {
    if (!lastMove) return false;
    return (
      (lastMove.from.row === r && lastMove.from.col === c) ||
      (lastMove.to.row === r && lastMove.to.col === c)
    );
  };

  const getLegalMoveForSquare = (r: number, c: number) => {
    return legalMoves.find(m => m.to.row === r && m.to.col === c);
  };

  const handleDragStart = (e: React.DragEvent, coord: SquareCoord) => {
    if (disabled || isThinking) {
      e.preventDefault();
      return;
    }
    const piece = board[coord.row][coord.col];
    if (!piece || piece.color !== turn) {
      e.preventDefault();
      return;
    }
    setDraggedCoord(coord);
    e.dataTransfer.setData('text/plain', JSON.stringify(coord));
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
  };

  const handleDrop = (e: React.DragEvent, targetCoord: SquareCoord) => {
    e.preventDefault();
    if (disabled || isThinking) {
      setDraggedCoord(null);
      return;
    }
    try {
      const data = e.dataTransfer.getData('text/plain');
      const fromCoord: SquareCoord = data ? JSON.parse(data) : draggedCoord;
      if (fromCoord) {
        onPieceDrop(fromCoord, targetCoord);
      }
    } catch {
      if (draggedCoord) {
        onPieceDrop(draggedCoord, targetCoord);
      }
    }
    setDraggedCoord(null);
  };

  return (
    <div className="relative select-none p-3 sm:p-5 rounded-2xl bg-gradient-to-b from-[#2d1b10] via-[#23150c] to-[#1a0f08] border border-[#52331f] shadow-2xl shadow-black/80 max-w-[560px] w-full mx-auto">
      {/* Decorative brass corner accents */}
      <div className="absolute top-2 left-2 w-3 h-3 border-t-2 border-l-2 border-[#c29853]/60 rounded-tl-sm pointer-events-none" />
      <div className="absolute top-2 right-2 w-3 h-3 border-t-2 border-r-2 border-[#c29853]/60 rounded-tr-sm pointer-events-none" />
      <div className="absolute bottom-2 left-2 w-3 h-3 border-b-2 border-l-2 border-[#c29853]/60 rounded-bl-sm pointer-events-none" />
      <div className="absolute bottom-2 right-2 w-3 h-3 border-b-2 border-r-2 border-[#c29853]/60 rounded-br-sm pointer-events-none" />

      {/* Main Board Container */}
      <div className="relative aspect-square w-full rounded-lg overflow-hidden border-2 border-[#452713] shadow-inner">
        <div className="grid grid-cols-8 grid-rows-8 w-full h-full">
          {Array.from({ length: 8 }).map((_, displayRow) =>
            Array.from({ length: 8 }).map((_, displayCol) => {
              const { row, col } = getBoardCoord(displayRow, displayCol);
              const piece = board[row][col];
              const isLight = (row + col) % 2 === 0;
              const selected = isSelected(row, col);
              const lastMoved = isLastMoveSquare(row, col);
              const legalMove = getLegalMoveForSquare(row, col);
              const isCheckingKing =
                isCheck && piece && piece.type === 'k' && piece.color === turn;

              // Color styles
              const squareBg = isLight
                ? 'bg-[#edd8b7]' // Classic light boxwood/cream
                : 'bg-[#965c37]'; // Classic dark walnut/rosewood

              return (
                <div
                  key={`${displayRow}-${displayCol}`}
                  onClick={() => !disabled && onSquareClick({ row, col })}
                  onDragOver={handleDragOver}
                  onDrop={e => handleDrop(e, { row, col })}
                  className={`relative flex items-center justify-center transition-colors duration-150 cursor-pointer ${squareBg}`}
                >
                  {/* Last Move Overlay */}
                  {lastMoved && (
                    <div className="absolute inset-0 bg-[#f59e0b]/35 mix-blend-multiply pointer-events-none" />
                  )}

                  {/* Selected Square Highlight */}
                  {selected && (
                    <div className="absolute inset-0 bg-[#eab308]/45 ring-2 ring-inset ring-[#ca8a04] pointer-events-none z-10" />
                  )}

                  {/* Check Indicator Glow */}
                  {isCheckingKing && (
                    <div className="absolute inset-0 bg-red-600/40 ring-4 ring-inset ring-red-500 animate-pulse pointer-events-none z-10" />
                  )}

                  {/* Legal Move Indicators */}
                  {legalMove && (
                    <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-20">
                      {piece ? (
                        // Capture indicator: outer ring
                        <div className="w-full h-full border-4 border-emerald-600/80 rounded-full scale-90 transition-transform animate-scale-in" />
                      ) : (
                        // Normal move indicator: center dot
                        <div className="w-3.5 h-3.5 sm:w-4 sm:h-4 rounded-full bg-emerald-700/70 shadow-sm" />
                      )}
                    </div>
                  )}

                  {/* Coordinate labels inside corner squares */}
                  {displayCol === 0 && (
                    <span
                      className={`absolute top-0.5 left-1 text-[9px] sm:text-[11px] font-semibold leading-none pointer-events-none ${
                        isLight ? 'text-[#965c37]' : 'text-[#edd8b7]'
                      }`}
                    >
                      {displayedRanks[displayRow]}
                    </span>
                  )}
                  {displayRow === 7 && (
                    <span
                      className={`absolute bottom-0.5 right-1 text-[9px] sm:text-[11px] font-semibold leading-none pointer-events-none ${
                        isLight ? 'text-[#965c37]' : 'text-[#edd8b7]'
                      }`}
                    >
                      {displayedFiles[displayCol]}
                    </span>
                  )}

                  {/* Chess Piece with Drag & Touch Support */}
                  {piece && (
                    <div
                      draggable={!disabled && !isThinking && piece.color === turn}
                      onDragStart={e => handleDragStart(e, { row, col })}
                      className={`relative w-[84%] h-[84%] z-10 flex items-center justify-center transition-transform hover:scale-105 active:scale-95 ${
                        draggedCoord?.row === row && draggedCoord?.col === col
                          ? 'opacity-40'
                          : 'opacity-100'
                      }`}
                    >
                      <ChessPiece type={piece.type} color={piece.color} />
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>

        {/* Subtle AI Thinking Indicator Banner over board */}
        {isThinking && (
          <div className="absolute top-3 left-1/2 -translate-x-1/2 z-30 flex items-center gap-2 px-3 py-1 bg-stone-950/85 backdrop-blur-md rounded-full border border-amber-600/40 text-amber-200 text-xs shadow-lg animate-pulse">
            <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
            <span className="font-medium tracking-wide">Komputer sedang menganalisis langkah...</span>
          </div>
        )}
      </div>
    </div>
  );
};
