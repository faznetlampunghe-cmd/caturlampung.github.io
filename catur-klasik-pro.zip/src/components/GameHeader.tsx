import React from 'react';
import { Sparkles, Info } from 'lucide-react';

interface GameHeaderProps {
  onNewGame: () => void;
  onOpenInfo: () => void;
}

export const GameHeader: React.FC<GameHeaderProps> = ({ onNewGame, onOpenInfo }) => {
  return (
    <header className="flex items-center justify-between gap-8 px-4 sm:px-8 py-3.5 border-b border-[#3d2719] bg-[#1a120c]/90 backdrop-blur-md sticky top-0 z-40">
      {/* Zone 1: Single text element brand wordmark */}
      <a
        href="#"
        onClick={e => {
          e.preventDefault();
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        className="font-serif text-lg sm:text-xl font-bold tracking-wider text-[#eedcc5] whitespace-nowrap shrink-0 flex items-center gap-2 hover:text-[#faebd7] transition-colors"
      >
        <span className="w-2.5 h-2.5 rounded-full bg-amber-500/80 inline-block shadow-sm" />
        CATUR KLASIK PRO
      </a>

      {/* Zone 2: Clean single-line text links */}
      <nav className="hidden md:flex items-center gap-6 text-xs sm:text-sm font-medium text-stone-300">
        <button
          onClick={onOpenInfo}
          className="hover:text-amber-200 transition-colors whitespace-nowrap shrink-0 text-left cursor-pointer"
        >
          Panduan AI & Offline
        </button>
        <button
          onClick={onOpenInfo}
          className="hover:text-amber-200 transition-colors whitespace-nowrap shrink-0 text-left cursor-pointer"
        >
          Aturan FIDE
        </button>
        <a
          href="#arena"
          className="hover:text-amber-200 transition-colors whitespace-nowrap shrink-0"
        >
          Meja Pertandingan
        </a>
      </nav>

      {/* Zone 3: 1 primary action */}
      <div className="flex items-center gap-2 shrink-0">
        <button
          onClick={onOpenInfo}
          title="Informasi & Panduan"
          className="md:hidden p-2 rounded-lg bg-[#2e1c12] text-stone-300 border border-[#4a2e1d] hover:text-amber-200"
        >
          <Info className="w-4 h-4" />
        </button>
        <button
          onClick={onNewGame}
          className="px-4 py-2 text-xs font-semibold text-white bg-gradient-to-r from-[#915a31] to-[#b07343] hover:from-[#a36537] hover:to-[#be7f4c] rounded-lg shadow-md border border-[#c48858]/40 transition-all whitespace-nowrap shrink-0 cursor-pointer active:scale-95"
        >
          Mulai Baru
        </button>
      </div>
    </header>
  );
};
