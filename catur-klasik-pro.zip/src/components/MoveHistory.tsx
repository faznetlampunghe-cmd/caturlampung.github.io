import React, { useEffect, useRef } from 'react';
import { Move } from '../types/chess';
import { ScrollText, Download, Copy, Check } from 'lucide-react';

interface MoveHistoryProps {
  history: Move[];
  onExportPGN: () => void;
}

export const MoveHistory: React.FC<MoveHistoryProps> = ({ history, onExportPGN }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [copied, setCopied] = React.useState(false);

  // Auto scroll to bottom when new move arrives
  useEffect(() => {
    if (containerRef.current) {
      containerRef.current.scrollTop = containerRef.current.scrollHeight;
    }
  }, [history.length]);

  // Group moves into pairs (White move, Black move)
  const movePairs: { num: number; white: string; black?: string }[] = [];
  for (let i = 0; i < history.length; i += 2) {
    movePairs.push({
      num: Math.floor(i / 2) + 1,
      white: history[i].san || '',
      black: history[i + 1]?.san,
    });
  }

  const handleCopySAN = () => {
    let text = '';
    movePairs.forEach(p => {
      text += `${p.num}. ${p.white} ${p.black || ''} `;
    });
    navigator.clipboard.writeText(text.trim());
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="flex flex-col h-full bg-[#1e1510]/90 rounded-xl border border-[#442c1c] overflow-hidden shadow-lg">
      {/* Header */}
      <div className="flex items-center justify-between px-3.5 py-2.5 bg-[#2a1b12] border-b border-[#442c1c]">
        <div className="flex items-center gap-2">
          <ScrollText className="w-4 h-4 text-amber-400" />
          <h3 className="text-xs font-semibold uppercase tracking-wider text-[#e6d8c3]">
            Notasi Langkah (SAN)
          </h3>
        </div>
        <div className="flex items-center gap-1">
          <button
            onClick={handleCopySAN}
            title="Salin Notasi Langkah"
            className="p-1 rounded text-stone-400 hover:text-amber-300 hover:bg-[#3d2719] transition-colors"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
          </button>
          <button
            onClick={onExportPGN}
            title="Unduh Berkas PGN"
            className="p-1 rounded text-stone-400 hover:text-amber-300 hover:bg-[#3d2719] transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Table Body */}
      <div
        ref={containerRef}
        className="flex-1 overflow-y-auto max-h-[220px] lg:max-h-[300px] p-2 text-xs font-mono scrollbar-thin scrollbar-thumb-[#452b1b] scrollbar-track-transparent"
      >
        {movePairs.length === 0 ? (
          <div className="h-full flex items-center justify-center text-stone-500 italic py-6">
            Belum ada langkah dimulai.
          </div>
        ) : (
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="text-stone-400 border-b border-[#3b2518] pb-1">
                <th className="w-10 py-1 font-normal">#</th>
                <th className="py-1 font-normal text-stone-300">Putih</th>
                <th className="py-1 font-normal text-stone-300">Hitam</th>
              </tr>
            </thead>
            <tbody>
              {movePairs.map(pair => (
                <tr
                  key={pair.num}
                  className="hover:bg-[#2e1d13]/60 transition-colors border-b border-[#2e1d13]/40"
                >
                  <td className="py-1 text-stone-500 tabular-nums">{pair.num}.</td>
                  <td className="py-1 text-amber-100 font-semibold">{pair.white}</td>
                  <td className="py-1 text-stone-300">{pair.black || ''}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Footer stats */}
      <div className="px-3 py-1.5 bg-[#251810] border-t border-[#3b2518] text-[11px] text-stone-400 flex justify-between items-center">
        <span>Total Langkah: <strong className="text-stone-200">{history.length}</strong></span>
        <span>Babak: <strong className="text-stone-200">{Math.ceil(history.length / 2) || 1}</strong></span>
      </div>
    </div>
  );
};
