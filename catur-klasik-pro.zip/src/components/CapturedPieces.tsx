import React from 'react';
import { Piece, PieceColor } from '../types/chess';
import { ChessPiece } from './ChessPiece';

interface CapturedPiecesProps {
  pieces: Piece[];
  color: PieceColor; // 'w' means this tray shows pieces captured BY White (so they are Black pieces)
  materialAdvantage: number;
}

export const CapturedPieces: React.FC<CapturedPiecesProps> = ({
  pieces,
  color,
  materialAdvantage,
}) => {
  // Sort pieces by value: p -> n -> b -> r -> q
  const typeOrder = { p: 1, n: 2, b: 3, r: 4, q: 5, k: 6 };
  const sorted = [...pieces].sort((a, b) => typeOrder[a.type] - typeOrder[b.type]);

  return (
    <div className="flex items-center gap-1.5 min-h-[32px] px-2.5 py-1 bg-[#1a1410]/80 rounded-lg border border-[#3b2719]">
      <div className="flex items-center -space-x-1.5 overflow-x-auto max-w-[220px] sm:max-w-[280px]">
        {sorted.map((piece, index) => (
          <div key={index} className="w-5 h-5 sm:w-6 sm:h-6 shrink-0 drop-shadow-sm">
            <ChessPiece type={piece.type} color={piece.color} />
          </div>
        ))}
      </div>
      {materialAdvantage > 0 && (
        <span className="text-[11px] font-mono font-bold text-amber-300 ml-1.5 shrink-0 bg-[#3a2617] px-1.5 py-0.5 rounded border border-amber-600/30">
          +{materialAdvantage}
        </span>
      )}
    </div>
  );
};
