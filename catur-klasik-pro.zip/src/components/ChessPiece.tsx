import React from 'react';
import { PieceColor, PieceType } from '../types/chess';

interface ChessPieceProps {
  type: PieceType;
  color: PieceColor;
  className?: string;
}

export const ChessPiece: React.FC<ChessPieceProps> = ({ type, color, className = 'w-full h-full' }) => {
  const isWhite = color === 'w';

  // Crisp standard international tournament piece vector paths
  switch (type) {
    case 'k':
      return (
        <svg viewBox="0 0 45 45" className={className} aria-label={`${isWhite ? 'White' : 'Black'} King`}>
          <g
            fill={isWhite ? '#ffffff' : '#1e1c19'}
            stroke={isWhite ? '#201d19' : '#e6d7c3'}
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            {/* Base */}
            <path d="M 22.5,11.5 L 22.5,6" strokeWidth="1.5" />
            <path d="M 20,8 L 25,8" strokeWidth="1.5" />
            <path d="M 22.5,25 C 22.5,25 27,17.5 25.5,14.5 C 25.5,14.5 24.5,12 22.5,12 C 20.5,12 19.5,14.5 19.5,14.5 C 18,17.5 22.5,25 22.5,25" />
            <path d="M 11.5,37 C 17,40.5 28,40.5 33.5,37 C 34.5,34 35,32 35,30 C 35,27.5 33,26 31.5,25.5 C 29,24.5 27.5,23.5 22.5,23.5 C 17.5,23.5 16,24.5 13.5,25.5 C 12,26 10,27.5 10,30 C 10,32 10.5,34 11.5,37 Z" />
            <path d="M 11.5,30 C 17,27 28,27 33.5,30" fill="none" />
            <path d="M 11.5,33.5 C 17,30.5 28,30.5 33.5,33.5" fill="none" />
            <path d="M 11.5,37 C 17,34 28,34 33.5,37" fill="none" />
            {/* Crown cross finial accent */}
            <circle cx="22.5" cy="14" r="1.5" fill={isWhite ? '#b58863' : '#d4af37'} stroke="none" />
          </g>
        </svg>
      );

    case 'q':
      return (
        <svg viewBox="0 0 45 45" className={className} aria-label={`${isWhite ? 'White' : 'Black'} Queen`}>
          <g
            fill={isWhite ? '#ffffff' : '#1e1c19'}
            stroke={isWhite ? '#201d19' : '#e6d7c3'}
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M 9,26 C 17.5,24.5 30,24.5 36,26 C 38.5,13.5 31,10 31,10 C 29,14 26,16 22.5,16 C 19,16 16,14 14,10 C 14,10 6.5,13.5 9,26 Z" />
            <path d="M 9,26 C 9,28 10.5,28 11.5,30 C 12.5,31.5 12.5,31 12,33.5 C 10.5,34.5 10.5,36 11.5,37 C 17,40.5 28,40.5 33.5,37 C 34.5,36 34.5,34.5 33,33.5 C 32.5,31 32.5,31.5 33.5,30 C 34.5,28 36,28 36,26" />
            <path d="M 11.5,30 C 17,27 28,27 33.5,30" fill="none" />
            <path d="M 12,33.5 C 17,30.5 28,30.5 33,33.5" fill="none" />
            <circle cx="6" cy="12" r="2" />
            <circle cx="14" cy="9" r="2" />
            <circle cx="22.5" cy="8" r="2" />
            <circle cx="31" cy="9" r="2" />
            <circle cx="39" cy="12" r="2" />
          </g>
        </svg>
      );

    case 'r':
      return (
        <svg viewBox="0 0 45 45" className={className} aria-label={`${isWhite ? 'White' : 'Black'} Rook`}>
          <g
            fill={isWhite ? '#ffffff' : '#1e1c19'}
            stroke={isWhite ? '#201d19' : '#e6d7c3'}
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M 9,39 L 36,39 L 36,36 L 9,36 Z" />
            <path d="M 12,36 L 12,32 L 33,32 L 33,36 Z" />
            <path d="M 11,14 L 34,14 L 34,9 L 31,9 L 31,11 L 28,11 L 28,9 L 25,9 L 25,11 L 20,11 L 20,9 L 17,9 L 17,11 L 14,11 L 14,9 L 11,9 Z" />
            <path d="M 12,32 L 14,14 L 31,14 L 33,32 Z" />
            <path d="M 14,29.5 L 31,29.5" fill="none" />
            <path d="M 14,16.5 L 31,16.5" fill="none" />
          </g>
        </svg>
      );

    case 'b':
      return (
        <svg viewBox="0 0 45 45" className={className} aria-label={`${isWhite ? 'White' : 'Black'} Bishop`}>
          <g
            fill={isWhite ? '#ffffff' : '#1e1c19'}
            stroke={isWhite ? '#201d19' : '#e6d7c3'}
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M 9,36 C 12.5,35 15,35 18,36 C 21.5,37 23.5,37 27,36 C 30,35 32.5,35 36,36 C 36,36 37.5,38.5 37.5,39 C 37.5,39.5 35,40 22.5,40 C 10,40 7.5,39.5 7.5,39 C 7.5,38.5 9,36 9,36 Z" />
            <path d="M 15,32 C 17.5,34.5 27.5,34.5 30,32 C 30.5,30.5 30,30 30,30 C 30,27.5 27.5,26 22.5,26 C 17.5,26 15,27.5 15,30 C 15,30 14.5,30.5 15,32 Z" />
            <path d="M 25,8 A 2.5 2.5 0 1 1 20,8 A 2.5 2.5 0 1 1 25,8 Z" />
            <path d="M 17.5,26 C 15,22.5 16,13 22.5,10.5 C 29,13 30,22.5 27.5,26 C 22.5,25 22.5,25 17.5,26 Z" />
            <path d="M 20,13 L 25,18" fill="none" />
            <path d="M 25,13 L 20,18" fill="none" />
          </g>
        </svg>
      );

    case 'n':
      return (
        <svg viewBox="0 0 45 45" className={className} aria-label={`${isWhite ? 'White' : 'Black'} Knight`}>
          <g
            fill={isWhite ? '#ffffff' : '#1e1c19'}
            stroke={isWhite ? '#201d19' : '#e6d7c3'}
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M 22,10 C 32.5,11 38.5,18 38,39 L 15,39 C 15,30 11,28 11,18 C 11,10 18,10 22,10 Z" />
            <path d="M 24,18 C 24.3,20 22,21.5 20,21 C 18,20.5 18,18 20,17 C 22,16 23.7,16 24,18 Z" fill={isWhite ? '#201d19' : '#e6d7c3'} />
            <path d="M 9.5,25.5 A 0.5 0.5 0 1 1 8.5,25.5 A 0.5 0.5 0 1 1 9.5,25.5 Z" />
            <path d="M 15,15.5 A 0.5 1.5 0 1 1 14,15.5 A 0.5 1.5 0 1 1 15,15.5 Z" />
            <path d="M 22,10 C 20,13 14,16 11,18" fill="none" />
            <path d="M 11.5,22 C 14,24 17,24 21,22.5" fill="none" />
          </g>
        </svg>
      );

    case 'p':
      return (
        <svg viewBox="0 0 45 45" className={className} aria-label={`${isWhite ? 'White' : 'Black'} Pawn`}>
          <g
            fill={isWhite ? '#ffffff' : '#1e1c19'}
            stroke={isWhite ? '#201d19' : '#e6d7c3'}
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M 22.5,9 A 3.5 3.5 0 1 1 15.5,9 A 3.5 3.5 0 1 1 22.5,9 Z" />
            <path d="M 19,16 A 1 1 0 0 1 26,16 C 26,19 25,21 27,24 C 29,27 29.5,30 31,34 C 31.5,35.5 30.5,37 29,37 L 16,37 C 14.5,37 13.5,35.5 14,34 C 15.5,30 16,27 18,24 C 20,21 19,19 19,16 Z" />
            <path d="M 11.5,37 L 33.5,37 L 33.5,40 L 11.5,40 Z" />
            <path d="M 16,32 C 20,30.5 25,30.5 29,32" fill="none" />
          </g>
        </svg>
      );

    default:
      return null;
  }
};
