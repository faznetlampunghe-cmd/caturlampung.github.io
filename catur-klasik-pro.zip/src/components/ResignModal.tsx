import React from 'react';
import { Flag, AlertTriangle } from 'lucide-react';
import { PieceColor } from '../types/chess';

interface ResignModalProps {
  isOpen: boolean;
  onCancel: () => void;
  onConfirm: () => void;
  isAIOpponent: boolean;
  turnColor?: PieceColor;
}

export const ResignModal: React.FC<ResignModalProps> = ({
  isOpen,
  onCancel,
  onConfirm,
  isAIOpponent,
  turnColor = 'w',
}) => {
  if (!isOpen) return null;

  const playerSide = turnColor === 'w' ? 'Putih' : 'Hitam';
  const opponentSide = turnColor === 'w' ? 'Hitam' : 'Putih';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-fade-in">
      <div className="bg-[#24170f] border-2 border-[#7a4827] rounded-2xl p-6 sm:p-7 shadow-2xl max-w-sm w-full text-center relative overflow-hidden">
        {/* Decorative corner accent */}
        <div className="absolute top-0 right-0 w-16 h-16 bg-rose-600/10 rounded-bl-full pointer-events-none" />

        <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-[#3d1e16] border-2 border-rose-700/60 text-rose-300 mb-4 shadow-inner">
          <Flag className="w-7 h-7 text-rose-400" />
        </div>

        <h3 className="font-serif text-lg sm:text-xl font-bold text-[#f5ecd8] mb-2">
          Konfirmasi Menyerah
        </h3>

        <p className="text-xs sm:text-sm text-stone-300/90 leading-relaxed mb-6">
          {isAIOpponent
            ? 'Apakah Anda yakin ingin menyerah pada babak ini? Kemenangan akan diberikan secara resmi kepada Komputer.'
            : `Apakah Pemain ${playerSide} yakin ingin menyerah? Kemenangan babak ini akan diberikan kepada Pemain ${opponentSide}.`}
        </p>

        <div className="flex gap-3">
          <button
            onClick={onCancel}
            className="flex-1 py-2.5 px-4 bg-[#352216] hover:bg-[#472d1e] text-stone-300 hover:text-white border border-[#5a3823] rounded-xl font-medium text-xs sm:text-sm transition-all cursor-pointer"
          >
            Lanjutkan Main
          </button>

          <button
            onClick={onConfirm}
            className="flex-1 py-2.5 px-4 bg-gradient-to-r from-rose-800 to-rose-700 hover:from-rose-700 hover:to-rose-600 text-white font-semibold rounded-xl text-xs sm:text-sm shadow-lg transition-all transform active:scale-95 cursor-pointer"
          >
            Ya, Menyerah
          </button>
        </div>
      </div>
    </div>
  );
};
