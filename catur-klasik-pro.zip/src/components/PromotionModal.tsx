import React from 'react';
import { PieceColor, PieceType } from '../types/chess';
import { ChessPiece } from './ChessPiece';

interface PromotionModalProps {
  color: PieceColor;
  onSelect: (type: PieceType) => void;
  onCancel?: () => void;
}

export const PromotionModal: React.FC<PromotionModalProps> = ({ color, onSelect, onCancel }) => {
  const pieces: { type: PieceType; name: string }[] = [
    { type: 'q', name: 'Menteri (Queen)' },
    { type: 'r', name: 'Benteng (Rook)' },
    { type: 'b', name: 'Gajah (Bishop)' },
    { type: 'n', name: 'Kuda (Knight)' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4 animate-fade-in">
      <div className="bg-[#24170f] border-2 border-[#6d4629] rounded-2xl p-6 shadow-2xl max-w-sm w-full text-center animate-scale-in">
        <h3 className="font-serif text-lg font-bold text-[#f2e6d6] mb-1">
          Promosi Pion
        </h3>
        <p className="text-xs text-stone-400 mb-5">
          Pilih bidak promosi kehormatan untuk pion Anda
        </p>

        <div className="grid grid-cols-4 gap-3 mb-4">
          {pieces.map(item => (
            <button
              key={item.type}
              onClick={() => onSelect(item.type)}
              className="flex flex-col items-center justify-center p-3 rounded-xl bg-[#352115] hover:bg-[#4a2e1d] border border-[#5a3823] hover:border-amber-500 transition-all transform hover:-translate-y-1 active:translate-y-0 group cursor-pointer"
            >
              <div className="w-12 h-12 mb-2 drop-shadow-md group-hover:scale-110 transition-transform">
                <ChessPiece type={item.type} color={color} />
              </div>
              <span className="text-[11px] font-semibold text-stone-300 group-hover:text-amber-200">
                {item.type.toUpperCase()}
              </span>
            </button>
          ))}
        </div>

        {onCancel && (
          <button
            onClick={onCancel}
            className="w-full py-2 bg-[#2d1b11] hover:bg-[#3d2719] text-stone-400 hover:text-stone-200 border border-[#4a2e1d] rounded-lg text-xs font-medium transition-colors cursor-pointer"
          >
            Batal Promosi (Pilih Langkah Lain)
          </button>
        )}
      </div>
    </div>
  );
};
