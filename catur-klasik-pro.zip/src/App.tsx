/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState, useRef, useTransition } from 'react';
import {
  Difficulty,
  GameMode,
  GameState,
  Move,
  PieceColor,
  PieceType,
  SquareCoord,
  TimeControlOption,
} from './types/chess';
import {
  calculateMaterialAdvantage,
  createInitialGameState,
  exportToPGN,
  getLegalMovesForSquare,
  makeMove,
} from './utils/chessEngine';
import { evaluateBoard, findBestMove } from './utils/chessAI';
import { soundEffects } from './utils/soundEffects';
import { downloadStandaloneHtml } from './utils/exportHtml';
import { GameHeader } from './components/GameHeader';
import { ChessBoard } from './components/ChessBoard';
import { PlayerCard } from './components/PlayerCard';
import { MoveHistory } from './components/MoveHistory';
import { GameControls } from './components/GameControls';
import { PromotionModal } from './components/PromotionModal';
import { GameOverModal } from './components/GameOverModal';
import { ResignModal } from './components/ResignModal';
import { InfoModal } from './components/InfoModal';
import { EvalBar } from './components/EvalBar';
import { ShieldCheck, BookOpen, Flag } from 'lucide-react';

export default function App() {
  const [gameState, setGameState] = useState<GameState>(createInitialGameState());
  const [gameMode, setGameMode] = useState<GameMode>('ai-white');
  const [difficulty, setDifficulty] = useState<Difficulty>('medium');
  const [orientation, setOrientation] = useState<PieceColor>('w');
  const [selectedSquare, setSelectedSquare] = useState<SquareCoord | null>(null);
  const [legalMoves, setLegalMoves] = useState<Move[]>([]);
  const [pendingPromotion, setPendingPromotion] = useState<Move | null>(null);
  const [isThinking, setIsThinking] = useState<boolean>(false);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [timeControl, setTimeControl] = useState<TimeControlOption>(0);
  const [whiteTime, setWhiteTime] = useState<number | null>(null);
  const [blackTime, setBlackTime] = useState<number | null>(null);
  const [isHintLoading, setIsHintLoading] = useState<boolean>(false);
  const [hintMove, setHintMove] = useState<Move | null>(null);
  const [showInfoModal, setShowInfoModal] = useState<boolean>(false);
  const [showResignModal, setShowResignModal] = useState<boolean>(false);
  const [stateStack, setStateStack] = useState<GameState[]>([]);

  const [, startTransition] = useTransition();
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const aiTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Initialize sound mute state on mount
  useEffect(() => {
    soundEffects.initMuteFromStorage();
    setIsMuted(soundEffects.getMuted());
  }, []);

  // Determine which side is AI
  const isAITurn = () => {
    if (gameState.isGameOver) return false;
    if (gameMode === 'pass-and-play') return false;
    if (gameMode === 'ai-white' && gameState.turn === 'b') return true;
    if (gameMode === 'ai-black' && gameState.turn === 'w') return true;
    return false;
  };

  // Clock Timer loop
  useEffect(() => {
    if (timeControl === 0 || gameState.isGameOver) {
      if (timerRef.current) clearInterval(timerRef.current);
      return;
    }

    timerRef.current = setInterval(() => {
      if (gameState.turn === 'w') {
        setWhiteTime(prev => {
          if (prev === null) return null;
          if (prev <= 1) {
            handleTimeForfeit('w');
            return 0;
          }
          return prev - 1;
        });
      } else {
        setBlackTime(prev => {
          if (prev === null) return null;
          if (prev <= 1) {
            handleTimeForfeit('b');
            return 0;
          }
          return prev - 1;
        });
      }
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [timeControl, gameState.turn, gameState.isGameOver]);

  const handleTimeForfeit = (timedOutColor: PieceColor) => {
    const winner = timedOutColor === 'w' ? 'b' : 'w';
    setGameState(prev => ({
      ...prev,
      isGameOver: true,
      winner,
    }));
    soundEffects.playGameOver(false);
  };

  // Trigger AI move when it's AI's turn
  useEffect(() => {
    if (isAITurn() && !gameState.isGameOver && !isThinking) {
      setIsThinking(true);

      aiTimeoutRef.current = setTimeout(() => {
        startTransition(() => {
          const aiResult = findBestMove(
            gameState.board,
            gameState.turn,
            gameState.castling,
            gameState.enPassantTarget,
            difficulty
          );

          if (aiResult.move) {
            executeMove(aiResult.move);
          }
          setIsThinking(false);
          aiTimeoutRef.current = null;
        });
      }, 450); // Realistic human simulation delay

      return () => {
        if (aiTimeoutRef.current) {
          clearTimeout(aiTimeoutRef.current);
          aiTimeoutRef.current = null;
        }
      };
    }
  }, [gameState.turn, gameMode, difficulty, gameState.isGameOver]);

  const executeMove = (move: Move) => {
    setStateStack(prev => [...prev, gameState]);
    const nextState = makeMove(gameState, move);
    setGameState(nextState);
    setSelectedSquare(null);
    setLegalMoves([]);
    setHintMove(null);

    // Play appropriate sound
    if (nextState.isCheckmate) {
      soundEffects.playGameOver(nextState.winner === (gameMode === 'ai-black' ? 'b' : 'w'));
    } else if (nextState.isCheck) {
      soundEffects.playCheck();
    } else if (move.captured || move.isEnPassant) {
      soundEffects.playCapture();
    } else if (move.isCastling) {
      soundEffects.playCastle();
    } else {
      soundEffects.playMove();
    }
  };

  // Requirement 1: Allow deselecting piece by clicking the same square or non-legal square
  const handleSquareClick = (square: SquareCoord) => {
    if (isThinking || gameState.isGameOver) return;
    if (isAITurn()) return;

    // 1. If clicking the exact same selected piece -> cancel selection!
    if (selectedSquare && selectedSquare.row === square.row && selectedSquare.col === square.col) {
      setSelectedSquare(null);
      setLegalMoves([]);
      setHintMove(null);
      return;
    }

    // 2. Check if clicked square is a legal move destination
    const destinationMove = legalMoves.find(
      m => m.to.row === square.row && m.to.col === square.col
    );

    if (destinationMove) {
      // Check if it's a pawn promotion
      if (destinationMove.promotion) {
        setPendingPromotion(destinationMove);
        return;
      }
      executeMove(destinationMove);
      return;
    }

    // 3. Check if user clicked another piece of their own turn
    const piece = gameState.board[square.row][square.col];
    if (piece && piece.color === gameState.turn) {
      setSelectedSquare(square);
      const moves = getLegalMovesForSquare(
        gameState.board,
        square,
        gameState.castling,
        gameState.enPassantTarget
      );
      setLegalMoves(moves);
      setHintMove(null);
    } else {
      // 4. Clicked on an empty square or opponent's piece that is NOT a legal move
      // -> Cancel selection cleanly without making any illegal move!
      setSelectedSquare(null);
      setLegalMoves([]);
      setHintMove(null);
    }
  };

  const handlePieceDrop = (from: SquareCoord, to: SquareCoord) => {
    if (isThinking || gameState.isGameOver) return;
    if (isAITurn()) return;

    // Dropping on same square -> deselect
    if (from.row === to.row && from.col === to.col) {
      setSelectedSquare(null);
      setLegalMoves([]);
      setHintMove(null);
      return;
    }

    const piece = gameState.board[from.row][from.col];
    if (!piece || piece.color !== gameState.turn) return;

    const availableMoves = getLegalMovesForSquare(
      gameState.board,
      from,
      gameState.castling,
      gameState.enPassantTarget
    );

    const validMove = availableMoves.find(m => m.to.row === to.row && m.to.col === to.col);
    if (validMove) {
      if (validMove.promotion) {
        setPendingPromotion(validMove);
        return;
      }
      executeMove(validMove);
    } else {
      // Invalid drop: cancel selection safely
      setSelectedSquare(null);
      setLegalMoves([]);
      setHintMove(null);
    }
  };

  const handlePromotionSelect = (type: PieceType) => {
    if (!pendingPromotion) return;
    const finalMove: Move = {
      ...pendingPromotion,
      promotion: type,
    };
    setPendingPromotion(null);
    executeMove(finalMove);
  };

  // Requirement 3: Reset board and resignation status completely
  const handleNewGame = () => {
    if (aiTimeoutRef.current) {
      clearTimeout(aiTimeoutRef.current);
      aiTimeoutRef.current = null;
    }
    setIsThinking(false);

    const fresh = createInitialGameState();
    setGameState(fresh);
    setStateStack([]);
    setSelectedSquare(null);
    setLegalMoves([]);
    setPendingPromotion(null);
    setHintMove(null);
    setShowResignModal(false);

    if (timeControl > 0) {
      setWhiteTime(timeControl);
      setBlackTime(timeControl);
    } else {
      setWhiteTime(null);
      setBlackTime(null);
    }

    soundEffects.playMove();
  };

  // Requirement 4: Undo move without corrupting game state
  const handleUndo = () => {
    if (isThinking || stateStack.length === 0) return;

    if (aiTimeoutRef.current) {
      clearTimeout(aiTimeoutRef.current);
      aiTimeoutRef.current = null;
    }
    setIsThinking(false);

    let targetState: GameState;
    if (gameMode !== 'pass-and-play' && stateStack.length >= 2 && !gameState.isResigned) {
      // In vs AI mode, undo both the AI response and player's move
      targetState = stateStack[stateStack.length - 2];
      setStateStack(prev => prev.slice(0, prev.length - 2));
    } else {
      targetState = stateStack[stateStack.length - 1];
      setStateStack(prev => prev.slice(0, prev.length - 1));
    }

    // Restore target state, ensuring game is active again
    setGameState({
      ...targetState,
      isGameOver: false,
      isResigned: false,
      resignedBy: null,
      winner: null,
    });

    setSelectedSquare(null);
    setLegalMoves([]);
    setHintMove(null);
    setPendingPromotion(null);
    setShowResignModal(false);
    soundEffects.playMove();
  };

  const handleFlipOrientation = () => {
    if (isThinking) return;
    setOrientation(prev => (prev === 'w' ? 'b' : 'w'));
  };

  const handleToggleMute = () => {
    const nextMute = !isMuted;
    setIsMuted(nextMute);
    soundEffects.setMuted(nextMute);
  };

  const handleTimeControlChange = (tc: TimeControlOption) => {
    if (isThinking) return;
    setTimeControl(tc);
    if (tc > 0) {
      setWhiteTime(tc);
      setBlackTime(tc);
    } else {
      setWhiteTime(null);
      setBlackTime(null);
    }
  };

  const handleGameModeChange = (mode: GameMode) => {
    if (isThinking) return;
    setGameMode(mode);
    if (mode === 'ai-black') {
      setOrientation('b');
    } else {
      setOrientation('w');
    }
    handleNewGame();
  };

  const handleGetHint = () => {
    if (gameState.isGameOver || isThinking || isHintLoading) return;
    setIsHintLoading(true);

    setTimeout(() => {
      const best = findBestMove(
        gameState.board,
        gameState.turn,
        gameState.castling,
        gameState.enPassantTarget,
        'hard'
      );
      if (best.move) {
        setHintMove(best.move);
        setSelectedSquare(best.move.from);
        setLegalMoves([best.move]);
      }
      setIsHintLoading(false);
    }, 250);
  };

  // Requirement 2: Open resignation confirmation dialog
  const handleResignClick = () => {
    if (gameState.isGameOver || isThinking) return;
    setShowResignModal(true);
  };

  // Requirement 2: Confirmed resignation
  const handleConfirmResign = () => {
    if (gameState.isGameOver) return;
    setShowResignModal(false);

    if (aiTimeoutRef.current) {
      clearTimeout(aiTimeoutRef.current);
      aiTimeoutRef.current = null;
    }
    setIsThinking(false);

    const resigningColor = gameState.turn;
    const opponentColor: PieceColor = resigningColor === 'w' ? 'b' : 'w';

    setGameState(prev => ({
      ...prev,
      isGameOver: true,
      isResigned: true,
      resignedBy: resigningColor,
      winner: opponentColor,
    }));

    setSelectedSquare(null);
    setLegalMoves([]);
    setHintMove(null);
    soundEffects.playGameOver(false);
  };

  const handleExportPGN = () => {
    const pgn = exportToPGN(gameState);
    const blob = new Blob([pgn], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `catur-klasik-${new Date().getTime()}.pgn`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // Calculate material difference
  const materialAdv = calculateMaterialAdvantage(gameState.capturedPieces);
  const evalScore = evaluateBoard(gameState.board);
  const lastMove = gameState.history.length > 0 ? gameState.history[gameState.history.length - 1] : null;

  // Determine Player / AI names based on current mode
  const whitePlayerName =
    gameMode === 'ai-black'
      ? `AI Catur (${difficulty.toUpperCase()})`
      : 'Pemain Putih';

  const blackPlayerName =
    gameMode === 'ai-white'
      ? `AI Catur (${difficulty.toUpperCase()})`
      : 'Pemain Hitam';

  const topPlayer = orientation === 'w' ? {
    name: blackPlayerName,
    isAI: gameMode === 'ai-white',
    color: 'b' as PieceColor,
    isTurn: gameState.turn === 'b',
    captured: gameState.capturedPieces.b,
    materialAdv: materialAdv.blackDiff,
    time: blackTime,
  } : {
    name: whitePlayerName,
    isAI: gameMode === 'ai-black',
    color: 'w' as PieceColor,
    isTurn: gameState.turn === 'w',
    captured: gameState.capturedPieces.w,
    materialAdv: materialAdv.whiteDiff,
    time: whiteTime,
  };

  const bottomPlayer = orientation === 'w' ? {
    name: whitePlayerName,
    isAI: gameMode === 'ai-black',
    color: 'w' as PieceColor,
    isTurn: gameState.turn === 'w',
    captured: gameState.capturedPieces.w,
    materialAdv: materialAdv.whiteDiff,
    time: whiteTime,
  } : {
    name: blackPlayerName,
    isAI: gameMode === 'ai-white',
    color: 'b' as PieceColor,
    isTurn: gameState.turn === 'b',
    captured: gameState.capturedPieces.b,
    materialAdv: materialAdv.blackDiff,
    time: blackTime,
  };

  return (
    <div className="min-h-screen bg-[#110e0b] text-[#f2e6d6] flex flex-col font-sans selection:bg-[#945f3a] selection:text-white">
      {/* Top Bar Header */}
      <GameHeader
        onNewGame={handleNewGame}
        onOpenInfo={() => setShowInfoModal(true)}
      />

      {/* Main Chess Arena */}
      <main id="arena" className="flex-1 max-w-[1440px] w-full mx-auto px-4 sm:px-6 lg:px-8 py-5">
        {/* Subtle Club Saloon Hero Kicker & Metadata */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 mb-4 border-b border-[#2d1b11]">
          <div className="flex items-center gap-3">
            <img
              src="/src/assets/images/chess_club_emblem_1791980014405.jpg"
              alt="Catur Klasik Pro Insignia"
              className="w-10 h-10 rounded-full border border-[#7d4f2e] shadow-md object-cover"
              referrerPolicy="no-referrer"
            />
            <div>
              <h1 className="font-serif text-lg sm:text-xl font-bold text-[#eedcc5] tracking-tight">
                Grandmaster Classical Salon
              </h1>
              <div className="flex items-center gap-2 text-xs text-stone-400">
                <span>Mesin AI Minimax Lokal</span>
                <span aria-hidden="true">·</span>
                <span>Aturan Resmi FIDE</span>
                <span aria-hidden="true">·</span>
                <span>100% Offline</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            {/* Quick Resign shortcut in arena header for fast access */}
            {!gameState.isGameOver && (
              <button
                onClick={handleResignClick}
                disabled={isThinking}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-rose-300 hover:text-white bg-[#331818] hover:bg-rose-900/60 border border-rose-800/50 rounded-lg transition-all cursor-pointer disabled:opacity-40"
                title="Menyerah pada permainan saat ini"
              >
                <Flag className="w-3.5 h-3.5 text-rose-400" />
                <span>Menyerah</span>
              </button>
            )}

            <button
              onClick={() => setShowInfoModal(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-stone-300 hover:text-amber-200 bg-[#24170f] hover:bg-[#342015] border border-[#4a2e1d] rounded-lg transition-colors cursor-pointer"
            >
              <BookOpen className="w-3.5 h-3.5 text-amber-400" />
              <span>Petunjuk & Panduan Offline</span>
            </button>
          </div>
        </div>

        {/* Resignation / Game Status Banner */}
        {gameState.isResigned && (
          <div className="mb-4 p-3 bg-rose-950/70 border border-rose-600/50 rounded-xl text-center text-xs sm:text-sm font-semibold text-rose-200 shadow-md animate-fade-in flex items-center justify-center gap-2">
            <Flag className="w-4 h-4 text-rose-400" />
            <span>
              {gameMode === 'pass-and-play'
                ? `Pemain ${gameState.resignedBy === 'w' ? 'Putih' : 'Hitam'} menyerah — Pemain ${gameState.winner === 'w' ? 'Putih' : 'Hitam'} menang. Seluruh langkah berikutnya dikunci.`
                : 'Anda menyerah — Komputer menang. Seluruh langkah berikutnya dikunci.'}
            </span>
          </div>
        )}

        {/* Game Layout Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Center-Left: Chessboard Column (7 cols on large desktop) */}
          <div className="lg:col-span-7 flex flex-col gap-3">
            {/* Top Opponent Card */}
            <PlayerCard
              name={topPlayer.name}
              isAI={topPlayer.isAI}
              color={topPlayer.color}
              isTurn={topPlayer.isTurn}
              capturedPieces={topPlayer.captured}
              materialAdvantage={topPlayer.materialAdv}
              timeRemaining={topPlayer.time}
            />

            {/* Chessboard with Interactive Legal Moves */}
            <ChessBoard
              board={gameState.board}
              turn={gameState.turn}
              orientation={orientation}
              selectedSquare={selectedSquare}
              legalMoves={legalMoves}
              lastMove={lastMove}
              isCheck={gameState.isCheck}
              onSquareClick={handleSquareClick}
              onPieceDrop={handlePieceDrop}
              isThinking={isThinking}
              disabled={gameState.isGameOver}
            />

            {/* Bottom Player Card */}
            <PlayerCard
              name={bottomPlayer.name}
              isAI={bottomPlayer.isAI}
              color={bottomPlayer.color}
              isTurn={bottomPlayer.isTurn}
              capturedPieces={bottomPlayer.captured}
              materialAdvantage={bottomPlayer.materialAdv}
              timeRemaining={bottomPlayer.time}
            />

            {/* Position Evaluation Bar */}
            <div className="p-2.5 bg-[#1a120c]/90 rounded-xl border border-[#3b2518]">
              <EvalBar score={evalScore} />
            </div>
          </div>

          {/* Right Column: Controls & Move History (5 cols on large desktop) */}
          <div className="lg:col-span-5 flex flex-col gap-4">
            {/* Control Panel (Modes, Difficulty, Undo, Flip, Mute, HTML Download, Resign) */}
            <GameControls
              difficulty={difficulty}
              onDifficultyChange={setDifficulty}
              gameMode={gameMode}
              onGameModeChange={handleGameModeChange}
              timeControl={timeControl}
              onTimeControlChange={handleTimeControlChange}
              onUndo={handleUndo}
              canUndo={stateStack.length > 0}
              onFlip={handleFlipOrientation}
              isMuted={isMuted}
              onToggleMute={handleToggleMute}
              onGetHint={handleGetHint}
              isHintLoading={isHintLoading}
              onDownloadHtml={downloadStandaloneHtml}
              onResign={handleResignClick}
              isGameOver={gameState.isGameOver}
              isThinking={isThinking}
            />

            {/* Move History Table */}
            <MoveHistory
              history={gameState.history}
              onExportPGN={handleExportPGN}
            />

            {/* Offline & Architecture Assurance Card */}
            <div className="relative overflow-hidden p-4 rounded-xl border border-[#442c1c] bg-[#1e140d]/90 shadow-sm text-xs text-stone-300">
              <div className="flex items-center gap-2 mb-1.5 text-amber-300 font-semibold">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>Jaminan Tanpa Dependensi Luar (100% Offline)</span>
              </div>
              <p className="text-stone-400 leading-relaxed text-[11px]">
                Seluruh aturan FIDE, pencarian algoritma minimax dengan pemangkasan alpha-beta, evaluasi tabel posisi (PST), dan sintesis suara Web Audio dieksekusi murni di mesin peramban Anda. Tidak memerlukan internet, API key, atau pendaftaran akun.
              </p>
            </div>
          </div>
        </div>
      </main>

      {/* Pawn Promotion Modal */}
      {pendingPromotion && (
        <PromotionModal
          color={pendingPromotion.piece.color}
          onSelect={handlePromotionSelect}
          onCancel={() => setPendingPromotion(null)}
        />
      )}

      {/* Resignation Confirmation Modal */}
      <ResignModal
        isOpen={showResignModal}
        onCancel={() => setShowResignModal(false)}
        onConfirm={handleConfirmResign}
        isAIOpponent={gameMode !== 'pass-and-play'}
        turnColor={gameState.turn}
      />

      {/* Game Over Modal */}
      {gameState.isGameOver && (
        <GameOverModal
          gameState={gameState}
          playerColor={gameMode === 'ai-black' ? 'b' : 'w'}
          gameMode={gameMode}
          onRestart={handleNewGame}
          onExportPGN={handleExportPGN}
        />
      )}

      {/* Info & Offline Guide Modal */}
      {showInfoModal && (
        <InfoModal
          onClose={() => setShowInfoModal(false)}
          onDownloadHtml={downloadStandaloneHtml}
        />
      )}
    </div>
  );
}
