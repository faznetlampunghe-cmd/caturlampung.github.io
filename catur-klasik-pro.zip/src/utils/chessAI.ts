import { Board, CastlingRights, Difficulty, Move, PieceColor, PieceType, SquareCoord } from '../types/chess';
import {
  applyMoveTemporarily,
  cloneBoard,
  getAllLegalMoves,
  isKingInCheck,
} from './chessEngine';

// Material base values
const PIECE_VALUES: Record<PieceType, number> = {
  p: 100,
  n: 320,
  b: 330,
  r: 500,
  q: 900,
  k: 20000,
};

// Piece-Square Tables (8x8, oriented from White's perspective: row 0 = rank 8, row 7 = rank 1)
const PAWN_PST: number[][] = [
  [0,  0,  0,  0,  0,  0,  0,  0],
  [50, 50, 50, 50, 50, 50, 50, 50],
  [10, 10, 20, 30, 30, 20, 10, 10],
  [5,  5, 10, 25, 25, 10,  5,  5],
  [0,  0,  0, 20, 20,  0,  0,  0],
  [5, -5,-10,  0,  0,-10, -5,  5],
  [5, 10, 10,-20,-20, 10, 10,  5],
  [0,  0,  0,  0,  0,  0,  0,  0],
];

const KNIGHT_PST: number[][] = [
  [-50,-40,-30,-30,-30,-30,-40,-50],
  [-40,-20,  0,  0,  0,  0,-20,-40],
  [-30,  0, 10, 15, 15, 10,  0,-30],
  [-30,  5, 15, 20, 20, 15,  5,-30],
  [-30,  0, 15, 20, 20, 15,  0,-30],
  [-30,  5, 10, 15, 15, 10,  5,-30],
  [-40,-20,  0,  5,  5,  0,-20,-40],
  [-50,-40,-30,-30,-30,-30,-40,-50],
];

const BISHOP_PST: number[][] = [
  [-20,-10,-10,-10,-10,-10,-10,-20],
  [-10,  0,  0,  0,  0,  0,  0,-10],
  [-10,  0,  5, 10, 10,  5,  0,-10],
  [-10,  5,  5, 10, 10,  5,  5,-10],
  [-10,  0, 10, 10, 10, 10,  0,-10],
  [-10, 10, 10, 10, 10, 10, 10,-10],
  [-10,  5,  0,  0,  0,  0,  5,-10],
  [-20,-10,-10,-10,-10,-10,-10,-20],
];

const ROOK_PST: number[][] = [
  [0,  0,  0,  0,  0,  0,  0,  0],
  [5, 10, 10, 10, 10, 10, 10,  5],
  [-5,  0,  0,  0,  0,  0,  0, -5],
  [-5,  0,  0,  0,  0,  0,  0, -5],
  [-5,  0,  0,  0,  0,  0,  0, -5],
  [-5,  0,  0,  0,  0,  0,  0, -5],
  [-5,  0,  0,  0,  0,  0,  0, -5],
  [0,  0,  0,  5,  5,  0,  0,  0],
];

const QUEEN_PST: number[][] = [
  [-20,-10,-10, -5, -5,-10,-10,-20],
  [-10,  0,  0,  0,  0,  0,  0,-10],
  [-10,  0,  5,  5,  5,  5,  0,-10],
  [-5,  0,  5,  5,  5,  5,  0, -5],
  [0,  0,  5,  5,  5,  5,  0, -5],
  [-10,  5,  5,  5,  5,  5,  0,-10],
  [-10,  0,  5,  0,  0,  0,  0,-10],
  [-20,-10,-10, -5, -5,-10,-10,-20],
];

const KING_MIDGAME_PST: number[][] = [
  [-30,-40,-40,-50,-50,-40,-40,-30],
  [-30,-40,-40,-50,-50,-40,-40,-30],
  [-30,-40,-40,-50,-50,-40,-40,-30],
  [-30,-40,-40,-50,-50,-40,-40,-30],
  [-20,-30,-30,-40,-40,-30,-30,-20],
  [-10,-20,-20,-20,-20,-20,-20,-10],
  [20, 20,  0,  0,  0,  0, 20, 20],
  [20, 30, 10,  0,  0, 10, 30, 20],
];

function getPieceSquareValue(piece: PieceType, color: PieceColor, r: number, c: number): number {
  // If Black, mirror row: row 0 becomes row 7
  const row = color === 'w' ? r : 7 - r;
  const col = c;

  switch (piece) {
    case 'p': return PAWN_PST[row][col];
    case 'n': return KNIGHT_PST[row][col];
    case 'b': return BISHOP_PST[row][col];
    case 'r': return ROOK_PST[row][col];
    case 'q': return QUEEN_PST[row][col];
    case 'k': return KING_MIDGAME_PST[row][col];
    default: return 0;
  }
}

// Static Board Evaluation
// Positive score favors White, Negative favors Black
export function evaluateBoard(board: Board): number {
  let score = 0;

  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const piece = board[r][c];
      if (piece) {
        const material = PIECE_VALUES[piece.type];
        const positional = getPieceSquareValue(piece.type, piece.color, r, c);
        const val = material + positional;
        if (piece.color === 'w') {
          score += val;
        } else {
          score -= val;
        }
      }
    }
  }

  return score;
}

// MVV-LVA (Most Valuable Victim - Least Valuable Attacker) heuristic
function getMoveScore(move: Move): number {
  let score = 0;

  if (move.captured) {
    const victimVal = PIECE_VALUES[move.captured.type];
    const attackerVal = PIECE_VALUES[move.piece.type];
    score += 10 * victimVal - attackerVal;
  }

  if (move.promotion) {
    score += PIECE_VALUES[move.promotion];
  }

  if (move.isCastling) {
    score += 60;
  }

  return score;
}

function orderMoves(moves: Move[]): Move[] {
  return [...moves].sort((a, b) => getMoveScore(b) - getMoveScore(a));
}

// Quiescence search to avoid horizon effect on captures
function quiescence(
  board: Board,
  alpha: number,
  beta: number,
  turn: PieceColor,
  depth: number,
  maxQDepth: number = 2
): number {
  const standPat = evaluateBoard(board);

  if (depth >= maxQDepth) {
    return standPat;
  }

  if (turn === 'w') {
    if (standPat >= beta) return beta;
    if (alpha < standPat) alpha = standPat;

    const pseudoLegal = getAllLegalMoves(board, 'w', { wK: false, wQ: false, bK: false, bQ: false }, null);
    const captures = pseudoLegal.filter(m => m.captured || m.promotion);
    const orderedCaptures = orderMoves(captures);

    for (const move of orderedCaptures) {
      const nextBoard = applyMoveTemporarily(board, move);
      const score = quiescence(nextBoard, alpha, beta, 'b', depth + 1, maxQDepth);
      if (score >= beta) return beta;
      if (score > alpha) alpha = score;
    }
    return alpha;
  } else {
    if (standPat <= alpha) return alpha;
    if (beta > standPat) beta = standPat;

    const pseudoLegal = getAllLegalMoves(board, 'b', { wK: false, wQ: false, bK: false, bQ: false }, null);
    const captures = pseudoLegal.filter(m => m.captured || m.promotion);
    const orderedCaptures = orderMoves(captures);

    for (const move of orderedCaptures) {
      const nextBoard = applyMoveTemporarily(board, move);
      const score = quiescence(nextBoard, alpha, beta, 'w', depth + 1, maxQDepth);
      if (score <= alpha) return alpha;
      if (score < beta) beta = score;
    }
    return beta;
  }
}

// Minimax with Alpha-Beta Pruning
function minimax(
  board: Board,
  depth: number,
  alpha: number,
  beta: number,
  turn: PieceColor,
  castling: CastlingRights,
  enPassantTarget: SquareCoord | null,
  useQuiescence: boolean
): number {
  const legalMoves = getAllLegalMoves(board, turn, castling, enPassantTarget);

  if (legalMoves.length === 0) {
    const inCheck = isKingInCheck(board, turn);
    if (inCheck) {
      // Checkmate: return huge negative for the mating side
      return turn === 'w' ? -100000 + depth : 100000 - depth;
    }
    // Stalemate
    return 0;
  }

  if (depth === 0) {
    if (useQuiescence) {
      return quiescence(board, alpha, beta, turn, 0, 2);
    }
    return evaluateBoard(board);
  }

  const orderedMoves = orderMoves(legalMoves);

  if (turn === 'w') {
    let maxEval = -Infinity;
    for (const move of orderedMoves) {
      const nextBoard = applyMoveTemporarily(board, move);
      const nextTurn: PieceColor = 'b';
      const ev = minimax(
        nextBoard,
        depth - 1,
        alpha,
        beta,
        nextTurn,
        castling,
        null,
        useQuiescence
      );
      maxEval = Math.max(maxEval, ev);
      alpha = Math.max(alpha, ev);
      if (beta <= alpha) {
        break; // Beta cutoff
      }
    }
    return maxEval;
  } else {
    let minEval = Infinity;
    for (const move of orderedMoves) {
      const nextBoard = applyMoveTemporarily(board, move);
      const nextTurn: PieceColor = 'w';
      const ev = minimax(
        nextBoard,
        depth - 1,
        alpha,
        beta,
        nextTurn,
        castling,
        null,
        useQuiescence
      );
      minEval = Math.min(minEval, ev);
      beta = Math.min(beta, ev);
      if (beta <= alpha) {
        break; // Alpha cutoff
      }
    }
    return minEval;
  }
}

export interface BestMoveResult {
  move: Move | null;
  score: number;
  depth: number;
  nodesEvaluated: number;
}

export function findBestMove(
  board: Board,
  turn: PieceColor,
  castling: CastlingRights,
  enPassantTarget: SquareCoord | null,
  difficulty: Difficulty
): BestMoveResult {
  const legalMoves = getAllLegalMoves(board, turn, castling, enPassantTarget);
  if (legalMoves.length === 0) {
    return { move: null, score: 0, depth: 0, nodesEvaluated: 0 };
  }

  // Easy mode: Depth 1 with small random variance for casual human play
  if (difficulty === 'easy') {
    const scoredMoves = legalMoves.map(move => {
      const nextBoard = applyMoveTemporarily(board, move);
      const baseEval = evaluateBoard(nextBoard);
      // Add randomness +-60 to give occasional mistakes
      const noise = (Math.random() - 0.5) * 120;
      return { move, score: (turn === 'w' ? baseEval : -baseEval) + noise };
    });

    scoredMoves.sort((a, b) => b.score - a.score);
    return {
      move: scoredMoves[0].move,
      score: scoredMoves[0].score,
      depth: 1,
      nodesEvaluated: legalMoves.length,
    };
  }

  // Medium mode: Depth 3 minimax with alpha-beta + PST
  // Hard mode: Depth 4 minimax with alpha-beta + PST + Quiescence
  const searchDepth = difficulty === 'medium' ? 3 : 4;
  const useQuiescence = difficulty === 'hard';

  const orderedMoves = orderMoves(legalMoves);
  let bestMove: Move = orderedMoves[0];
  let bestScore = turn === 'w' ? -Infinity : Infinity;
  let alpha = -Infinity;
  let beta = Infinity;
  let evaluated = 0;

  for (const move of orderedMoves) {
    evaluated++;
    const nextBoard = applyMoveTemporarily(board, move);
    const nextTurn: PieceColor = turn === 'w' ? 'b' : 'w';

    const currentEval = minimax(
      nextBoard,
      searchDepth - 1,
      alpha,
      beta,
      nextTurn,
      castling,
      null,
      useQuiescence
    );

    if (turn === 'w') {
      if (currentEval > bestScore) {
        bestScore = currentEval;
        bestMove = move;
      }
      alpha = Math.max(alpha, currentEval);
    } else {
      if (currentEval < bestScore) {
        bestScore = currentEval;
        bestMove = move;
      }
      beta = Math.min(beta, currentEval);
    }
  }

  return {
    move: bestMove,
    score: bestScore,
    depth: searchDepth,
    nodesEvaluated: evaluated,
  };
}
