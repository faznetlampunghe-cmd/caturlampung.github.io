/**
 * Generates a 100% self-contained single-file HTML chess game.
 * Requires 0 external network requests, 0 CDN, 0 API keys.
 * Can be opened in any web browser completely offline.
 */
export function generateStandaloneChessHtml(): string {
  return `<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Catur Klasik Pro - Edisi Mandiri Offline</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      background: #14100c;
      color: #ede4d4;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 16px;
    }
    header {
      width: 100%;
      max-width: 900px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 12px 20px;
      border-bottom: 1px solid #3d2718;
      margin-bottom: 20px;
    }
    .brand {
      font-size: 1.25rem;
      font-weight: 700;
      color: #f1dfc6;
      letter-spacing: 0.05em;
    }
    .container {
      width: 100%;
      max-width: 900px;
      display: grid;
      grid-template-columns: 1fr;
      gap: 20px;
    }
    @media(min-width: 768px) {
      .container { grid-template-columns: 500px 1fr; }
    }
    .board-frame {
      background: #25160c;
      border: 3px solid #55341c;
      border-radius: 12px;
      padding: 12px;
      box-shadow: 0 10px 25px rgba(0,0,0,0.7);
    }
    .board {
      display: grid;
      grid-template-columns: repeat(8, 1fr);
      grid-template-rows: repeat(8, 1fr);
      aspect-ratio: 1;
      width: 100%;
      border: 2px solid #3a2212;
      border-radius: 4px;
      overflow: hidden;
      position: relative;
    }
    .sq {
      display: flex;
      align-items: center;
      justify-content: center;
      position: relative;
      cursor: pointer;
      user-select: none;
    }
    .sq.light { background: #edd8b7; }
    .sq.dark { background: #965c37; }
    .sq.selected { background: #eab308 !important; }
    .sq.last-move { background: rgba(245, 158, 11, 0.45) !important; }
    .sq.check { background: rgba(220, 38, 38, 0.55) !important; }
    .legal-dot {
      width: 14px;
      height: 14px;
      border-radius: 50%;
      background: rgba(16, 185, 129, 0.7);
      pointer-events: none;
    }
    .legal-ring {
      position: absolute;
      inset: 4px;
      border: 4px solid rgba(16, 185, 129, 0.8);
      border-radius: 50%;
      pointer-events: none;
    }
    .coord-rank {
      position: absolute;
      top: 2px;
      left: 3px;
      font-size: 10px;
      font-weight: 700;
      color: #664124;
      pointer-events: none;
    }
    .sq.dark .coord-rank { color: #eeddc5; }
    .coord-file {
      position: absolute;
      bottom: 2px;
      right: 3px;
      font-size: 10px;
      font-weight: 700;
      color: #664124;
      pointer-events: none;
    }
    .sq.dark .coord-file { color: #eeddc5; }
    .piece-svg {
      width: 82%;
      height: 82%;
      pointer-events: none;
      filter: drop-shadow(0 2px 3px rgba(0,0,0,0.3));
    }
    .panel {
      background: #1c130c;
      border: 1px solid #3b2618;
      border-radius: 12px;
      padding: 16px;
      display: flex;
      flex-direction: column;
      gap: 14px;
    }
    .turn-bar {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 10px 14px;
      background: #2b1b11;
      border-radius: 8px;
      border: 1px solid #4a2e1d;
    }
    .btn {
      padding: 8px 14px;
      background: #3a2517;
      border: 1px solid #5a3822;
      color: #eddac3;
      border-radius: 6px;
      cursor: pointer;
      font-size: 13px;
      font-weight: 600;
      transition: all 0.15s;
    }
    .btn:hover { background: #4e3220; border-color: #c29853; }
    .btn.primary { background: #965c37; color: white; border-color: #b57a50; }
    .btn.primary:hover { background: #aa6e45; }
    .history-box {
      background: #150e09;
      border: 1px solid #2e1d13;
      border-radius: 6px;
      padding: 8px;
      height: 180px;
      overflow-y: auto;
      font-family: monospace;
      font-size: 12px;
    }
    .modal {
      display: none;
      position: fixed;
      inset: 0;
      background: rgba(0,0,0,0.8);
      align-items: center;
      justify-content: center;
      z-index: 100;
    }
    .modal.active { display: flex; }
    .modal-content {
      background: #25160d;
      border: 2px solid #6b4327;
      border-radius: 12px;
      padding: 24px;
      text-align: center;
      max-width: 360px;
      width: 90%;
    }
    select {
      background: #2b1b11;
      border: 1px solid #4a2e1d;
      color: #eddac3;
      padding: 6px 10px;
      border-radius: 6px;
      font-size: 13px;
    }
  </style>
</head>
<body>
  <header>
    <div class="brand">CATUR KLASIK PRO (EDISI OFFLINE)</div>
    <div style="font-size: 12px; color: #a89481;">AI Minimax Alpha-Beta Lokal</div>
  </header>

  <div class="container">
    <div>
      <div class="board-frame">
        <div id="board" class="board"></div>
      </div>
    </div>

    <div class="panel">
      <div class="turn-bar">
        <div>Giliran: <strong id="turnLabel" style="color: #f59e0b;">Putih (Pemain)</strong></div>
        <div id="statusLabel" style="font-size: 12px; color: #10b981;">Aktif</div>
      </div>

      <div style="display: flex; gap: 8px; align-items: center;">
        <label for="modeSelect" style="font-size: 12px;">Mode:</label>
        <select id="modeSelect">
          <option value="ai" selected>Lawan Komputer</option>
          <option value="pass">Dua Pemain (Satu Perangkat)</option>
        </select>
      </div>

      <div style="display: flex; gap: 8px; align-items: center;">
        <label for="diffSelect" style="font-size: 12px;">Kesulitan AI:</label>
        <select id="diffSelect">
          <option value="easy">Mudah (Depth 1)</option>
          <option value="medium" selected>Menengah (Depth 3)</option>
          <option value="hard">Sulit (Depth 4)</option>
        </select>
      </div>

      <div style="display: flex; gap: 8px;">
        <button id="btnNew" class="btn primary" style="flex: 1;">Mulai Baru</button>
        <button id="btnUndo" class="btn" style="flex: 1;">Batal Langkah</button>
        <button id="btnResign" class="btn" style="background: #441a1a; border-color: #7f2b2b; color: #fca5a5;">Menyerah</button>
        <button id="btnFlip" class="btn">Balik</button>
      </div>

      <div>
        <div style="font-size: 12px; margin-bottom: 6px; font-weight: 600; color: #b8a391;">Riwayat Langkah:</div>
        <div id="historyBox" class="history-box"></div>
      </div>

      <div style="font-size: 11px; color: #887261; line-height: 1.5; border-top: 1px solid #2e1d13; pt: 8px;">
        Aplikasi mandiri ini 100% berjalan langsung di peramban Anda tanpa internet, tanpa server, dan tanpa kuota data.
      </div>
    </div>
  </div>

  <div id="promoModal" class="modal">
    <div class="modal-content">
      <h3 style="margin-bottom: 12px;">Pilih Promosi Pion</h3>
      <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 8px;">
        <button class="btn" onclick="handlePromo('q')">Menteri (Q)</button>
        <button class="btn" onclick="handlePromo('r')">Benteng (R)</button>
        <button class="btn" onclick="handlePromo('b')">Gajah (B)</button>
        <button class="btn" onclick="handlePromo('n')">Kuda (N)</button>
      </div>
    </div>
  </div>

  <script>
    // Pure Standalone Chess Engine in JavaScript
    const PIECE_SVGS = {
      w: {
        k: '<svg viewBox="0 0 45 45"><g fill="#fff" stroke="#222" stroke-width="1.5"><path d="M22.5 11.5v-5.5M20 8h5M22.5 25c0 0 4.5-7.5 3-10.5 0 0-1-2.5-3-2.5s-3 2.5-3 2.5c-1.5 3 3 10.5 3 10.5"/><path d="M11.5 37c5.5 3.5 16.5 3.5 22 0 1-3 1.5-5 1.5-7 0-2.5-2-4-3.5-4.5-2.5-1-4-2-9-2s-6.5 1-9 2c-1.5.5-3.5 2-3.5 4.5 0 2 .5 4 1.5 7z"/></g></svg>',
        q: '<svg viewBox="0 0 45 45"><g fill="#fff" stroke="#222" stroke-width="1.5"><path d="M9 26c8.5-1.5 21-1.5 27 0 2.5-12.5-5-16-5-16-2 4-5 6-8.5 6s-6.5-2-8.5-6c0 0-7.5 3.5-5 16z"/><path d="M11.5 37c5.5 3.5 16.5 3.5 22 0 1-1 1-2.5-.5-3.5-.5-2.5-.5-2 1-3.5 1-1.5-.5-1.5-.5-3.5-8.5-1.5-21-1.5-27 0 0 2-1.5 2-.5 3.5 1.5 1.5 1.5 1 1 3.5-1.5 1-1.5 2.5-.5 3.5z"/><circle cx="6" cy="12" r="2"/><circle cx="14" cy="9" r="2"/><circle cx="22.5" cy="8" r="2"/><circle cx="31" cy="9" r="2"/><circle cx="39" cy="12" r="2"/></g></svg>',
        r: '<svg viewBox="0 0 45 45"><g fill="#fff" stroke="#222" stroke-width="1.5"><path d="M9 39h27v-3H9zm3-3v-4h21v4zm-1-22h23v-5h-3v2h-3v-2h-3v2h-5v-2h-3v2h-3v-2h-3zm1 18l2-18h17l2 18z"/></g></svg>',
        b: '<svg viewBox="0 0 45 45"><g fill="#fff" stroke="#222" stroke-width="1.5"><path d="M9 36c3.5-1 6-1 9 0 3.5 1 5.5 1 9 0 3-1 5.5-1 9 0 0 0 1.5 2.5 1.5 3 0 .5-2.5 1-15 1S7.5 39.5 7.5 39c0-.5 1.5-3 1.5-3zm6-4c2.5 2.5 12.5 2.5 15 0 .5-1.5 0-2 0-2-2.5-1.5-5-2-10-2s-7.5.5-7.5 2c0 0-.5.5 2.5 2z"/><circle cx="22.5" cy="8" r="2.5"/><path d="M17.5 26c-2.5-3.5-1.5-13 5-15.5 6.5 2.5 7.5 12 5 15.5-5-1-5-1-10 0z"/></g></svg>',
        n: '<svg viewBox="0 0 45 45"><g fill="#fff" stroke="#222" stroke-width="1.5"><path d="M22 10c10.5 1 16.5 8 16 29H15c0-9-4-11-4-21 0-8 7-8 11-8z"/><path d="M24 18c.3 2-2 3.5-4 3s-2-3 0-4 3.7-1 4 1z" fill="#222"/></g></svg>',
        p: '<svg viewBox="0 0 45 45"><g fill="#fff" stroke="#222" stroke-width="1.5"><circle cx="22.5" cy="9" r="3.5"/><path d="M19 16c0-1 7-1 7 0 0 3-1 5 1 8 2 3 2.5 6 4 10 .5 1.5-.5 3-2 3H16c-1.5 0-2.5-1.5-2-3 1.5-4 2-7 4-10 2-3 1-5 1-8zm-7.5 21h22v3h-22z"/></g></svg>'
      },
      b: {
        k: '<svg viewBox="0 0 45 45"><g fill="#1a1410" stroke="#f0d9b5" stroke-width="1.5"><path d="M22.5 11.5v-5.5M20 8h5M22.5 25c0 0 4.5-7.5 3-10.5 0 0-1-2.5-3-2.5s-3 2.5-3 2.5c-1.5 3 3 10.5 3 10.5"/><path d="M11.5 37c5.5 3.5 16.5 3.5 22 0 1-3 1.5-5 1.5-7 0-2.5-2-4-3.5-4.5-2.5-1-4-2-9-2s-6.5 1-9 2c-1.5.5-3.5 2-3.5 4.5 0 2 .5 4 1.5 7z"/></g></svg>',
        q: '<svg viewBox="0 0 45 45"><g fill="#1a1410" stroke="#f0d9b5" stroke-width="1.5"><path d="M9 26c8.5-1.5 21-1.5 27 0 2.5-12.5-5-16-5-16-2 4-5 6-8.5 6s-6.5-2-8.5-6c0 0-7.5 3.5-5 16z"/><path d="M11.5 37c5.5 3.5 16.5 3.5 22 0 1-1 1-2.5-.5-3.5-.5-2.5-.5-2 1-3.5 1-1.5-.5-1.5-.5-3.5-8.5-1.5-21-1.5-27 0 0 2-1.5 2-.5 3.5 1.5 1.5 1.5 1 1 3.5-1.5 1-1.5 2.5-.5 3.5z"/><circle cx="6" cy="12" r="2"/><circle cx="14" cy="9" r="2"/><circle cx="22.5" cy="8" r="2"/><circle cx="31" cy="9" r="2"/><circle cx="39" cy="12" r="2"/></g></svg>',
        r: '<svg viewBox="0 0 45 45"><g fill="#1a1410" stroke="#f0d9b5" stroke-width="1.5"><path d="M9 39h27v-3H9zm3-3v-4h21v4zm-1-22h23v-5h-3v2h-3v-2h-3v2h-5v-2h-3v2h-3v-2h-3zm1 18l2-18h17l2 18z"/></g></svg>',
        b: '<svg viewBox="0 0 45 45"><g fill="#1a1410" stroke="#f0d9b5" stroke-width="1.5"><path d="M9 36c3.5-1 6-1 9 0 3.5 1 5.5 1 9 0 3-1 5.5-1 9 0 0 0 1.5 2.5 1.5 3 0 .5-2.5 1-15 1S7.5 39.5 7.5 39c0-.5 1.5-3 1.5-3zm6-4c2.5 2.5 12.5 2.5 15 0 .5-1.5 0-2 0-2-2.5-1.5-5-2-10-2s-7.5.5-7.5 2c0 0-.5.5 2.5 2z"/><circle cx="22.5" cy="8" r="2.5"/><path d="M17.5 26c-2.5-3.5-1.5-13 5-15.5 6.5 2.5 7.5 12 5 15.5-5-1-5-1-10 0z"/></g></svg>',
        n: '<svg viewBox="0 0 45 45"><g fill="#1a1410" stroke="#f0d9b5" stroke-width="1.5"><path d="M22 10c10.5 1 16.5 8 16 29H15c0-9-4-11-4-21 0-8 7-8 11-8z"/><path d="M24 18c.3 2-2 3.5-4 3s-2-3 0-4 3.7-1 4 1z" fill="#f0d9b5"/></g></svg>',
        p: '<svg viewBox="0 0 45 45"><g fill="#1a1410" stroke="#f0d9b5" stroke-width="1.5"><circle cx="22.5" cy="9" r="3.5"/><path d="M19 16c0-1 7-1 7 0 0 3-1 5 1 8 2 3 2.5 6 4 10 .5 1.5-.5 3-2 3H16c-1.5 0-2.5-1.5-2-3 1.5-4 2-7 4-10 2-3 1-5 1-8zm-7.5 21h22v3h-22z"/></g></svg>'
      }
    };

    let board = [];
    let turn = 'w';
    let castling = { wK: true, wQ: true, bK: true, bQ: true };
    let enPassant = null;
    let selectedSquare = null;
    let legalMoves = [];
    let lastMove = null;
    let history = [];
    let stateStack = [];
    let flipped = false;
    let pendingPromoMove = null;
    let isGameOver = false;
    let isResigned = false;

    function initBoard() {
      board = Array(8).fill(null).map(() => Array(8).fill(null));
      const back = ['r','n','b','q','k','b','n','r'];
      for(let i=0; i<8; i++) {
        board[0][i] = { type: back[i], color: 'b' };
        board[1][i] = { type: 'p', color: 'b' };
        board[6][i] = { type: 'p', color: 'w' };
        board[7][i] = { type: back[i], color: 'w' };
      }
      turn = 'w';
      castling = { wK: true, wQ: true, bK: true, bQ: true };
      enPassant = null;
      selectedSquare = null;
      legalMoves = [];
      lastMove = null;
      history = [];
      stateStack = [];
      isGameOver = false;
      isResigned = false;
      updateUI();
    }

    function cloneB(b) {
      return b.map(row => row.map(cell => cell ? {...cell} : null));
    }

    function isSquareAttacked(b, sq, byColor) {
      const r = sq.row, c = sq.col;
      // Pawns
      const pRow = byColor === 'w' ? r + 1 : r - 1;
      if (pRow >= 0 && pRow < 8) {
        for (const pc of [c - 1, c + 1]) {
          if (pc >= 0 && pc < 8 && b[pRow][pc]?.color === byColor && b[pRow][pc]?.type === 'p') return true;
        }
      }
      // Knights
      const nOffsets = [[-2,-1],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]];
      for (const [dr, dc] of nOffsets) {
        const nr = r + dr, nc = c + dc;
        if (nr >= 0 && nr < 8 && nc >= 0 && nc < 8 && b[nr][nc]?.color === byColor && b[nr][nc]?.type === 'n') return true;
      }
      // Diagonals (Bishop/Queen)
      const diag = [[-1,-1],[-1,1],[1,-1],[1,1]];
      for (const [dr, dc] of diag) {
        let nr = r + dr, nc = c + dc;
        while (nr>=0 && nr<8 && nc>=0 && nc<8) {
          if (b[nr][nc]) {
            if (b[nr][nc].color === byColor && (b[nr][nc].type==='b'||b[nr][nc].type==='q')) return true;
            break;
          }
          nr += dr; nc += dc;
        }
      }
      // Straight (Rook/Queen)
      const st = [[-1,0],[1,0],[0,-1],[0,1]];
      for (const [dr, dc] of st) {
        let nr = r + dr, nc = c + dc;
        while (nr>=0 && nr<8 && nc>=0 && nc<8) {
          if (b[nr][nc]) {
            if (b[nr][nc].color === byColor && (b[nr][nc].type==='r'||b[nr][nc].type==='q')) return true;
            break;
          }
          nr += dr; nc += dc;
        }
      }
      // King
      const kOff = [[-1,-1],[-1,0],[-1,1],[0,-1],[0,1],[1,-1],[1,0],[1,1]];
      for (const [dr, dc] of kOff) {
        const nr = r + dr, nc = c + dc;
        if (nr >= 0 && nr < 8 && nc >= 0 && nc < 8 && b[nr][nc]?.color === byColor && b[nr][nc]?.type === 'k') return true;
      }
      return false;
    }

    function findKing(b, col) {
      for(let r=0; r<8; r++) {
        for(let c=0; c<8; c++) {
          if (b[r][c]?.type === 'k' && b[r][c]?.color === col) return { row: r, col: c };
        }
      }
      return null;
    }

    function isKingCheck(b, col) {
      const k = findKing(b, col);
      return k ? isSquareAttacked(b, k, col === 'w' ? 'b' : 'w') : false;
    }

    function getMoves(b, r, c, castl, ep) {
      const p = b[r][c];
      if (!p) return [];
      const enemy = p.color === 'w' ? 'b' : 'w';
      const moves = [];

      if (p.type === 'p') {
        const dir = p.color === 'w' ? -1 : 1;
        const startR = p.color === 'w' ? 6 : 1;
        const promoR = p.color === 'w' ? 0 : 7;
        const f1 = r + dir;
        if (f1 >= 0 && f1 < 8 && !b[f1][c]) {
          if (f1 === promoR) {
            ['q','r','b','n'].forEach(promo => moves.push({ from: {row:r,col:c}, to: {row:f1,col:c}, piece: p, promo }));
          } else {
            moves.push({ from: {row:r,col:c}, to: {row:f1,col:c}, piece: p });
            const f2 = r + 2*dir;
            if (r === startR && !b[f2][c]) moves.push({ from: {row:r,col:c}, to: {row:f2,col:c}, piece: p });
          }
        }
        for (const dc of [-1, 1]) {
          const capC = c + dc;
          if (capC >= 0 && capC < 8 && f1 >= 0 && f1 < 8) {
            if (b[f1][capC] && b[f1][capC].color === enemy) {
              if (f1 === promoR) {
                ['q','r','b','n'].forEach(promo => moves.push({ from: {row:r,col:c}, to: {row:f1,col:capC}, piece: p, promo, captured: b[f1][capC] }));
              } else {
                moves.push({ from: {row:r,col:c}, to: {row:f1,col:capC}, piece: p, captured: b[f1][capC] });
              }
            } else if (ep && ep.row === f1 && ep.col === capC) {
              moves.push({ from: {row:r,col:c}, to: {row:f1,col:capC}, piece: p, isEp: true, captured: b[r][capC] });
            }
          }
        }
      } else if (p.type === 'n') {
        const offs = [[-2,-1],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]];
        for (const [dr, dc] of offs) {
          const nr = r + dr, nc = c + dc;
          if (nr>=0 && nr<8 && nc>=0 && nc<8 && (!b[nr][nc] || b[nr][nc].color === enemy)) {
            moves.push({ from: {row:r,col:c}, to: {row:nr,col:nc}, piece: p, captured: b[nr][nc] });
          }
        }
      } else if (p.type === 'b' || p.type === 'r' || p.type === 'q') {
        const dirs = [];
        if (p.type === 'b' || p.type === 'q') dirs.push([-1,-1],[-1,1],[1,-1],[1,1]);
        if (p.type === 'r' || p.type === 'q') dirs.push([-1,0],[1,0],[0,-1],[0,1]);
        for (const [dr, dc] of dirs) {
          let nr = r + dr, nc = c + dc;
          while (nr>=0 && nr<8 && nc>=0 && nc<8) {
            if (!b[nr][nc]) {
              moves.push({ from: {row:r,col:c}, to: {row:nr,col:nc}, piece: p });
            } else {
              if (b[nr][nc].color === enemy) moves.push({ from: {row:r,col:c}, to: {row:nr,col:nc}, piece: p, captured: b[nr][nc] });
              break;
            }
            nr += dr; nc += dc;
          }
        }
      } else if (p.type === 'k') {
        const dirs = [[-1,-1],[-1,0],[-1,1],[0,-1],[0,1],[1,-1],[1,0],[1,1]];
        for (const [dr, dc] of dirs) {
          const nr = r + dr, nc = c + dc;
          if (nr>=0 && nr<8 && nc>=0 && nc<8 && (!b[nr][nc] || b[nr][nc].color === enemy)) {
            moves.push({ from: {row:r,col:c}, to: {row:nr,col:nc}, piece: p, captured: b[nr][nc] });
          }
        }
        // Castling
        const kr = p.color === 'w' ? 7 : 0;
        if (r === kr && c === 4 && !isSquareAttacked(b, {row: kr, col: 4}, enemy)) {
          const canK = p.color === 'w' ? castl.wK : castl.bK;
          const canQ = p.color === 'w' ? castl.wQ : castl.bQ;
          if (canK && !b[kr][5] && !b[kr][6] && b[kr][7]?.type === 'r' && !isSquareAttacked(b, {row:kr,col:5}, enemy) && !isSquareAttacked(b, {row:kr,col:6}, enemy)) {
            moves.push({ from: {row:r,col:c}, to: {row:kr,col:6}, piece: p, isCastling: 'k' });
          }
          if (canQ && !b[kr][1] && !b[kr][2] && !b[kr][3] && b[kr][0]?.type === 'r' && !isSquareAttacked(b, {row:kr,col:3}, enemy) && !isSquareAttacked(b, {row:kr,col:2}, enemy)) {
            moves.push({ from: {row:r,col:c}, to: {row:kr,col:2}, piece: p, isCastling: 'q' });
          }
        }
      }

      // Filter illegal checks
      return moves.filter(m => {
        const nb = cloneB(b);
        nb[m.from.row][m.from.col] = null;
        nb[m.to.row][m.to.col] = m.promo ? { type: m.promo, color: p.color } : {...p};
        if (m.isEp) nb[m.from.row][m.to.col] = null;
        if (m.isCastling === 'k') { nb[m.from.row][5] = nb[m.from.row][7]; nb[m.from.row][7] = null; }
        if (m.isCastling === 'q') { nb[m.from.row][3] = nb[m.from.row][0]; nb[m.from.row][0] = null; }
        return !isKingCheck(nb, p.color);
      });
    }

    function getAllMoves(b, col, castl, ep) {
      const all = [];
      for(let r=0; r<8; r++) {
        for(let c=0; c<8; c++) {
          if (b[r][c]?.color === col) all.push(...getMoves(b, r, c, castl, ep));
        }
      }
      return all;
    }

    function applyMove(m) {
      stateStack.push({
        board: cloneB(board),
        turn,
        castling: {...castling},
        enPassant: enPassant ? {...enPassant} : null,
        lastMove
      });

      board[m.from.row][m.from.col] = null;
      board[m.to.row][m.to.col] = m.promo ? { type: m.promo, color: m.piece.color } : {...m.piece};
      if (m.isEp) board[m.from.row][m.to.col] = null;
      if (m.isCastling === 'k') { board[m.from.row][5] = board[m.from.row][7]; board[m.from.row][7] = null; }
      if (m.isCastling === 'q') { board[m.from.row][3] = board[m.from.row][0]; board[m.from.row][0] = null; }

      // Update castling rights
      if (m.piece.type === 'k') {
        if (m.piece.color === 'w') { castling.wK = false; castling.wQ = false; }
        else { castling.bK = false; castling.bQ = false; }
      } else if (m.piece.type === 'r') {
        if (m.from.row === 7 && m.from.col === 7) castling.wK = false;
        if (m.from.row === 7 && m.from.col === 0) castling.wQ = false;
        if (m.from.row === 0 && m.from.col === 7) castling.bK = false;
        if (m.from.row === 0 && m.from.col === 0) castling.bQ = false;
      }

      if (m.piece.type === 'p' && Math.abs(m.to.row - m.from.row) === 2) {
        enPassant = { row: (m.from.row + m.to.row)/2, col: m.from.col };
      } else {
        enPassant = null;
      }

      lastMove = m;
      turn = turn === 'w' ? 'b' : 'w';

      const files = ['a','b','c','d','e','f','g','h'];
      const san = (m.piece.type !== 'p' ? m.piece.type.toUpperCase() : '') +
                  (m.captured ? 'x' : '') +
                  files[m.to.col] + (8 - m.to.row) + (m.promo ? '='+m.promo.toUpperCase() : '');
      history.push(san);

      updateUI();

      if (turn === 'b' && document.getElementById('modeSelect')?.value !== 'pass') {
        setTimeout(playAIMove, 300);
      }
    }

    // Minimax AI with Alpha-Beta
    const PVAL = { p: 100, n: 320, b: 330, r: 500, q: 900, k: 20000 };
    function evalB(b) {
      let score = 0;
      for(let r=0; r<8; r++) {
        for(let c=0; c<8; c++) {
          const p = b[r][c];
          if (p) score += (p.color === 'w' ? 1 : -1) * PVAL[p.type];
        }
      }
      return score;
    }

    function minimax(b, depth, alpha, beta, isMax, castl, ep) {
      if (depth === 0) return evalB(b);
      const moves = getAllMoves(b, isMax ? 'w' : 'b', castl, ep);
      if (moves.length === 0) {
        return isKingCheck(b, isMax ? 'w' : 'b') ? (isMax ? -99999 : 99999) : 0;
      }
      if (isMax) {
        let maxE = -Infinity;
        for (const m of moves) {
          const nb = cloneB(b);
          nb[m.from.row][m.from.col] = null;
          nb[m.to.row][m.to.col] = m.promo ? { type: m.promo, color: 'w' } : {...m.piece};
          const ev = minimax(nb, depth - 1, alpha, beta, false, castl, null);
          maxE = Math.max(maxE, ev);
          alpha = Math.max(alpha, ev);
          if (beta <= alpha) break;
        }
        return maxE;
      } else {
        let minE = Infinity;
        for (const m of moves) {
          const nb = cloneB(b);
          nb[m.from.row][m.from.col] = null;
          nb[m.to.row][m.to.col] = m.promo ? { type: m.promo, color: 'b' } : {...m.piece};
          const ev = minimax(nb, depth - 1, alpha, beta, true, castl, null);
          minE = Math.min(minE, ev);
          beta = Math.min(beta, ev);
          if (beta <= alpha) break;
        }
        return minE;
      }
    }

    function playAIMove() {
      const diff = document.getElementById('diffSelect').value;
      const depth = diff === 'easy' ? 1 : diff === 'medium' ? 3 : 4;
      const moves = getAllMoves(board, 'b', castling, enPassant);
      if (moves.length === 0) return;

      let bestM = moves[0];
      let bestVal = Infinity;
      let alpha = -Infinity, beta = Infinity;

      for (const m of moves) {
        const nb = cloneB(board);
        nb[m.from.row][m.from.col] = null;
        nb[m.to.row][m.to.col] = m.promo ? { type: m.promo, color: 'b' } : {...m.piece};
        let val = minimax(nb, depth - 1, alpha, beta, true, castling, null);
        if (diff === 'easy') val += (Math.random() - 0.5) * 80;
        if (val < bestVal) {
          bestVal = val;
          bestM = m;
        }
        beta = Math.min(beta, val);
      }

      applyMove(bestM);
    }

    function handlePromo(type) {
      document.getElementById('promoModal').classList.remove('active');
      if (pendingPromoMove) {
        pendingPromoMove.promo = type;
        applyMove(pendingPromoMove);
        pendingPromoMove = null;
      }
    }

    function onSquareClick(r, c) {
      const isPass = document.getElementById('modeSelect')?.value === 'pass';
      if (!isPass && turn !== 'w') return;
      if (isGameOver) return;

      // Click same selected piece to deselect
      if (selectedSquare && selectedSquare.row === r && selectedSquare.col === c) {
        selectedSquare = null;
        legalMoves = [];
        updateUI();
        return;
      }

      const legal = legalMoves.find(m => m.to.row === r && m.to.col === c);
      if (legal) {
        if (legal.promo) {
          pendingPromoMove = legal;
          document.getElementById('promoModal').classList.add('active');
          return;
        }
        selectedSquare = null;
        legalMoves = [];
        applyMove(legal);
        return;
      }

      const p = board[r][c];
      if (p && p.color === turn) {
        selectedSquare = { row: r, col: c };
        legalMoves = getMoves(board, r, c, castling, enPassant);
      } else {
        selectedSquare = null;
        legalMoves = [];
      }
      updateUI();
    }

    function updateUI() {
      const boardEl = document.getElementById('board');
      boardEl.innerHTML = '';

      const files = ['a','b','c','d','e','f','g','h'];
      const ranks = ['8','7','6','5','4','3','2','1'];

      for (let vr = 0; vr < 8; vr++) {
        for (let vc = 0; vc < 8; vc++) {
          const r = flipped ? 7 - vr : vr;
          const c = flipped ? 7 - vc : vc;
          const p = board[r][c];

          const sq = document.createElement('div');
          sq.className = 'sq ' + ((r + c) % 2 === 0 ? 'light' : 'dark');

          if (selectedSquare && selectedSquare.row === r && selectedSquare.col === c) {
            sq.classList.add('selected');
          }
          if (lastMove && ((lastMove.from.row === r && lastMove.from.col === c) || (lastMove.to.row === r && lastMove.to.col === c))) {
            sq.classList.add('last-move');
          }
          if (p?.type === 'k' && p.color === turn && isKingCheck(board, turn)) {
            sq.classList.add('check');
          }

          if (vc === 0) {
            const rk = document.createElement('span');
            rk.className = 'coord-rank';
            rk.textContent = ranks[r];
            sq.appendChild(rk);
          }
          if (vr === 7) {
            const fl = document.createElement('span');
            fl.className = 'coord-file';
            fl.textContent = files[c];
            sq.appendChild(fl);
          }

          const isLegal = legalMoves.find(m => m.to.row === r && m.to.col === c);
          if (isLegal) {
            const dot = document.createElement('div');
            dot.className = p ? 'legal-ring' : 'legal-dot';
            sq.appendChild(dot);
          }

          if (p) {
            const wrap = document.createElement('div');
            wrap.className = 'piece-svg';
            wrap.innerHTML = PIECE_SVGS[p.color][p.type];
            sq.appendChild(wrap);
          }

          sq.onclick = () => onSquareClick(r, c);
          boardEl.appendChild(sq);
        }
      }

      const isPass = document.getElementById('modeSelect')?.value === 'pass';
      document.getElementById('turnLabel').textContent = turn === 'w' ? (isPass ? 'Putih (Pemain 1)' : 'Putih (Pemain)') : (isPass ? 'Hitam (Pemain 2)' : 'Hitam (Komputer)');
      document.getElementById('turnLabel').style.color = turn === 'w' ? '#f59e0b' : '#38bdf8';

      const isCheck = isKingCheck(board, turn);
      const allM = getAllMoves(board, turn, castling, enPassant);
      const statusEl = document.getElementById('statusLabel');

      if (isResigned) {
        statusEl.textContent = 'Anda menyerah — Komputer menang';
        statusEl.style.color = '#ef4444';
      } else if (allM.length === 0) {
        isGameOver = true;
        if (isCheck) {
          statusEl.textContent = 'SKAKMAT! ' + (turn === 'w' ? 'Hitam' : 'Putih') + ' Menang!';
          statusEl.style.color = '#ef4444';
        } else {
          statusEl.textContent = 'REMIS (Stalemate)!';
          statusEl.style.color = '#94a3b8';
        }
      } else if (isCheck) {
        statusEl.textContent = 'SKAK!';
        statusEl.style.color = '#f87171';
      } else {
        statusEl.textContent = 'Aktif';
        statusEl.style.color = '#10b981';
      }

      // History
      const hBox = document.getElementById('historyBox');
      let hHtml = '';
      for(let i=0; i<history.length; i+=2) {
        const num = Math.floor(i/2) + 1;
        hHtml += '<div style="display:flex; justify-content:space-between; padding:2px 0;"><span style="color:#777;">' + num + '.</span><span style="color:#e0d2c0; font-weight:600;">' + history[i] + '</span><span style="color:#aaa;">' + (history[i+1]||'') + '</span></div>';
      }
      hBox.innerHTML = hHtml || '<div style="color:#666; text-align:center; padding:20px;">Belum ada langkah</div>';
      hBox.scrollTop = hBox.scrollHeight;
    }

    document.getElementById('btnNew').onclick = () => initBoard();
    document.getElementById('btnFlip').onclick = () => { flipped = !flipped; updateUI(); };
    document.getElementById('btnResign').onclick = () => {
      if (isGameOver) return;
      if (confirm('Apakah Anda yakin ingin menyerah pada permainan ini? Komputer akan menang.')) {
        isGameOver = true;
        isResigned = true;
        selectedSquare = null;
        legalMoves = [];
        updateUI();
      }
    };
    document.getElementById('btnUndo').onclick = () => {
      if (stateStack.length >= 1) {
        const prev = (isResigned || stateStack.length === 1) ? stateStack.pop() : (stateStack.pop(), stateStack.pop());
        if (prev) {
          board = prev.board;
          turn = prev.turn;
          castling = prev.castling;
          enPassant = prev.enPassant;
          lastMove = prev.lastMove;
          history.pop();
          if (!isResigned) history.pop();
        }
        isGameOver = false;
        isResigned = false;
        selectedSquare = null;
        legalMoves = [];
        updateUI();
      }
    };

    initBoard();
  </script>
</body>
</html>`;
}

export function downloadStandaloneHtml() {
  const content = generateStandaloneChessHtml();
  const blob = new Blob([content], { type: 'text/html;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'catur-klasik-pro-offline.html';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
