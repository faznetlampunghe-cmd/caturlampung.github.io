import { Board, CastlingRights, GameState, Move, Piece, PieceColor, PieceType, SquareCoord } from '../types/chess';

export function createInitialBoard(): Board {
  const board: Board = Array(8).fill(null).map(() => Array(8).fill(null));

  // Rank 8 (Black back row, index 0)
  board[0] = [
    { type: 'r', color: 'b' },
    { type: 'n', color: 'b' },
    { type: 'b', color: 'b' },
    { type: 'q', color: 'b' },
    { type: 'k', color: 'b' },
    { type: 'b', color: 'b' },
    { type: 'n', color: 'b' },
    { type: 'r', color: 'b' },
  ];
  // Rank 7 (Black pawns, index 1)
  board[1] = Array(8).fill(null).map(() => ({ type: 'p', color: 'b' }));

  // Empty ranks 6, 5, 4, 3 (indices 2, 3, 4, 5)

  // Rank 2 (White pawns, index 6)
  board[6] = Array(8).fill(null).map(() => ({ type: 'p', color: 'w' }));

  // Rank 1 (White back row, index 7)
  board[7] = [
    { type: 'r', color: 'w' },
    { type: 'n', color: 'w' },
    { type: 'b', color: 'w' },
    { type: 'q', color: 'w' },
    { type: 'k', color: 'w' },
    { type: 'b', color: 'w' },
    { type: 'n', color: 'w' },
    { type: 'r', color: 'w' },
  ];

  return board;
}

export function cloneBoard(board: Board): Board {
  return board.map(row => row.map(cell => (cell ? { ...cell } : null)));
}

export function createInitialGameState(): GameState {
  const board = createInitialBoard();
  const initialFenPos = getBoardPositionHash(board, 'w', { wK: true, wQ: true, bK: true, bQ: true }, null);
  return {
    board,
    turn: 'w',
    castling: { wK: true, wQ: true, bK: true, bQ: true },
    enPassantTarget: null,
    halfmoveClock: 0,
    fullmoveNumber: 1,
    history: [],
    isCheck: false,
    isCheckmate: false,
    isStalemate: false,
    isDrawFiftyMoves: false,
    isDrawRepetition: false,
    isDrawInsufficientMaterial: false,
    isGameOver: false,
    isResigned: false,
    resignedBy: null,
    winner: null,
    capturedPieces: { w: [], b: [] },
    positionHistory: [initialFenPos],
  };
}

export function coordToAlgebraic(coord: SquareCoord): string {
  const files = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'];
  return `${files[coord.col]}${8 - coord.row}`;
}

export function algebraicToCoord(algebraic: string): SquareCoord {
  const col = algebraic.charCodeAt(0) - 'a'.charCodeAt(0);
  const row = 8 - parseInt(algebraic[1], 10);
  return { row, col };
}

export function isWithinBoard(row: number, col: number): boolean {
  return row >= 0 && row < 8 && col >= 0 && col < 8;
}

export function isSquareAttacked(board: Board, square: SquareCoord, byColor: PieceColor): boolean {
  const { row, col } = square;

  // 1. Pawn attacks
  const pawnPusherRow = byColor === 'w' ? row + 1 : row - 1;
  const pawnCols = [col - 1, col + 1];
  for (const pCol of pawnCols) {
    if (isWithinBoard(pawnPusherRow, pCol)) {
      const piece = board[pawnPusherRow][pCol];
      if (piece && piece.color === byColor && piece.type === 'p') {
        return true;
      }
    }
  }

  // 2. Knight attacks
  const knightOffsets = [
    [-2, -1], [-2, 1], [-1, -2], [-1, 2],
    [1, -2], [1, 2], [2, -1], [2, 1],
  ];
  for (const [dr, dc] of knightOffsets) {
    const r = row + dr;
    const c = col + dc;
    if (isWithinBoard(r, c)) {
      const piece = board[r][c];
      if (piece && piece.color === byColor && piece.type === 'n') {
        return true;
      }
    }
  }

  // 3. Bishop & Queen diagonal rays
  const diagDirs = [[-1, -1], [-1, 1], [1, -1], [1, 1]];
  for (const [dr, dc] of diagDirs) {
    let r = row + dr;
    let c = col + dc;
    while (isWithinBoard(r, c)) {
      const piece = board[r][c];
      if (piece) {
        if (piece.color === byColor && (piece.type === 'b' || piece.type === 'q')) {
          return true;
        }
        break; // Obstructed
      }
      r += dr;
      c += dc;
    }
  }

  // 4. Rook & Queen straight rays
  const straightDirs = [[-1, 0], [1, 0], [0, -1], [0, 1]];
  for (const [dr, dc] of straightDirs) {
    let r = row + dr;
    let c = col + dc;
    while (isWithinBoard(r, c)) {
      const piece = board[r][c];
      if (piece) {
        if (piece.color === byColor && (piece.type === 'r' || piece.type === 'q')) {
          return true;
        }
        break; // Obstructed
      }
      r += dr;
      c += dc;
    }
  }

  // 5. King adjacent squares
  const kingOffsets = [
    [-1, -1], [-1, 0], [-1, 1],
    [0, -1],           [0, 1],
    [1, -1],  [1, 0],  [1, 1],
  ];
  for (const [dr, dc] of kingOffsets) {
    const r = row + dr;
    const c = col + dc;
    if (isWithinBoard(r, c)) {
      const piece = board[r][c];
      if (piece && piece.color === byColor && piece.type === 'k') {
        return true;
      }
    }
  }

  return false;
}

export function findKing(board: Board, color: PieceColor): SquareCoord | null {
  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const piece = board[r][c];
      if (piece && piece.type === 'k' && piece.color === color) {
        return { row: r, col: c };
      }
    }
  }
  return null;
}

export function isKingInCheck(board: Board, color: PieceColor): boolean {
  const kingPos = findKing(board, color);
  if (!kingPos) return false;
  const enemyColor: PieceColor = color === 'w' ? 'b' : 'w';
  return isSquareAttacked(board, kingPos, enemyColor);
}

// Pseudo-legal move generator (without check filtration)
export function getPseudoLegalMoves(
  board: Board,
  from: SquareCoord,
  castling: CastlingRights,
  enPassantTarget: SquareCoord | null
): Move[] {
  const piece = board[from.row][from.col];
  if (!piece) return [];

  const moves: Move[] = [];
  const { row, col } = from;
  const color = piece.color;
  const enemyColor: PieceColor = color === 'w' ? 'b' : 'w';

  switch (piece.type) {
    case 'p': {
      const direction = color === 'w' ? -1 : 1;
      const startRow = color === 'w' ? 6 : 1;
      const promotionRow = color === 'w' ? 0 : 7;

      // 1 square forward
      const oneStepRow = row + direction;
      if (isWithinBoard(oneStepRow, col) && !board[oneStepRow][col]) {
        if (oneStepRow === promotionRow) {
          (['q', 'r', 'b', 'n'] as PieceType[]).forEach(promo => {
            moves.push({
              from,
              to: { row: oneStepRow, col },
              piece,
              promotion: promo,
            });
          });
        } else {
          moves.push({ from, to: { row: oneStepRow, col }, piece });

          // 2 squares forward from start rank
          const twoStepRow = row + 2 * direction;
          if (row === startRow && isWithinBoard(twoStepRow, col) && !board[twoStepRow][col]) {
            moves.push({ from, to: { row: twoStepRow, col }, piece });
          }
        }
      }

      // Diagonal captures
      const captureCols = [col - 1, col + 1];
      for (const capCol of captureCols) {
        if (isWithinBoard(oneStepRow, capCol)) {
          const targetPiece = board[oneStepRow][capCol];
          if (targetPiece && targetPiece.color === enemyColor) {
            if (oneStepRow === promotionRow) {
              (['q', 'r', 'b', 'n'] as PieceType[]).forEach(promo => {
                moves.push({
                  from,
                  to: { row: oneStepRow, col: capCol },
                  piece,
                  captured: targetPiece,
                  promotion: promo,
                });
              });
            } else {
              moves.push({
                from,
                to: { row: oneStepRow, col: capCol },
                piece,
                captured: targetPiece,
              });
            }
          } else if (
            enPassantTarget &&
            enPassantTarget.row === oneStepRow &&
            enPassantTarget.col === capCol
          ) {
            // En passant capture!
            const capturedPawn = board[row][capCol];
            moves.push({
              from,
              to: { row: oneStepRow, col: capCol },
              piece,
              captured: capturedPawn,
              isEnPassant: true,
            });
          }
        }
      }
      break;
    }

    case 'n': {
      const knightOffsets = [
        [-2, -1], [-2, 1], [-1, -2], [-1, 2],
        [1, -2], [1, 2], [2, -1], [2, 1],
      ];
      for (const [dr, dc] of knightOffsets) {
        const r = row + dr;
        const c = col + dc;
        if (isWithinBoard(r, c)) {
          const target = board[r][c];
          if (!target || target.color === enemyColor) {
            moves.push({
              from,
              to: { row: r, col: c },
              piece,
              captured: target || undefined,
            });
          }
        }
      }
      break;
    }

    case 'b': {
      const diagDirs = [[-1, -1], [-1, 1], [1, -1], [1, 1]];
      for (const [dr, dc] of diagDirs) {
        let r = row + dr;
        let c = col + dc;
        while (isWithinBoard(r, c)) {
          const target = board[r][c];
          if (!target) {
            moves.push({ from, to: { row: r, col: c }, piece });
          } else {
            if (target.color === enemyColor) {
              moves.push({ from, to: { row: r, col: c }, piece, captured: target });
            }
            break;
          }
          r += dr;
          c += dc;
        }
      }
      break;
    }

    case 'r': {
      const straightDirs = [[-1, 0], [1, 0], [0, -1], [0, 1]];
      for (const [dr, dc] of straightDirs) {
        let r = row + dr;
        let c = col + dc;
        while (isWithinBoard(r, c)) {
          const target = board[r][c];
          if (!target) {
            moves.push({ from, to: { row: r, col: c }, piece });
          } else {
            if (target.color === enemyColor) {
              moves.push({ from, to: { row: r, col: c }, piece, captured: target });
            }
            break;
          }
          r += dr;
          c += dc;
        }
      }
      break;
    }

    case 'q': {
      const queenDirs = [
        [-1, -1], [-1, 1], [1, -1], [1, 1],
        [-1, 0], [1, 0], [0, -1], [0, 1],
      ];
      for (const [dr, dc] of queenDirs) {
        let r = row + dr;
        let c = col + dc;
        while (isWithinBoard(r, c)) {
          const target = board[r][c];
          if (!target) {
            moves.push({ from, to: { row: r, col: c }, piece });
          } else {
            if (target.color === enemyColor) {
              moves.push({ from, to: { row: r, col: c }, piece, captured: target });
            }
            break;
          }
          r += dr;
          c += dc;
        }
      }
      break;
    }

    case 'k': {
      const kingDirs = [
        [-1, -1], [-1, 0], [-1, 1],
        [0, -1],           [0, 1],
        [1, -1],  [1, 0],  [1, 1],
      ];
      for (const [dr, dc] of kingDirs) {
        const r = row + dr;
        const c = col + dc;
        if (isWithinBoard(r, c)) {
          const target = board[r][c];
          if (!target || target.color === enemyColor) {
            moves.push({
              from,
              to: { row: r, col: c },
              piece,
              captured: target || undefined,
            });
          }
        }
      }

      // Castling
      const isWhite = color === 'w';
      const kingRow = isWhite ? 7 : 0;
      if (row === kingRow && col === 4) {
        // Must not be currently in check
        const inCheck = isSquareAttacked(board, { row: kingRow, col: 4 }, enemyColor);

        if (!inCheck) {
          // Kingside castling
          const canKingside = isWhite ? castling.wK : castling.bK;
          if (canKingside) {
            const sq5Empty = !board[kingRow][5];
            const sq6Empty = !board[kingRow][6];
            const rook = board[kingRow][7];
            if (
              sq5Empty &&
              sq6Empty &&
              rook &&
              rook.type === 'r' &&
              rook.color === color &&
              !isSquareAttacked(board, { row: kingRow, col: 5 }, enemyColor) &&
              !isSquareAttacked(board, { row: kingRow, col: 6 }, enemyColor)
            ) {
              moves.push({
                from,
                to: { row: kingRow, col: 6 },
                piece,
                isCastling: 'kingside',
              });
            }
          }

          // Queenside castling
          const canQueenside = isWhite ? castling.wQ : castling.bQ;
          if (canQueenside) {
            const sq1Empty = !board[kingRow][1];
            const sq2Empty = !board[kingRow][2];
            const sq3Empty = !board[kingRow][3];
            const rook = board[kingRow][0];
            if (
              sq1Empty &&
              sq2Empty &&
              sq3Empty &&
              rook &&
              rook.type === 'r' &&
              rook.color === color &&
              !isSquareAttacked(board, { row: kingRow, col: 3 }, enemyColor) &&
              !isSquareAttacked(board, { row: kingRow, col: 2 }, enemyColor)
            ) {
              moves.push({
                from,
                to: { row: kingRow, col: 2 },
                piece,
                isCastling: 'queenside',
              });
            }
          }
        }
      }
      break;
    }
  }

  return moves;
}

// Applies move on a cloned board to check if the King is safe
export function applyMoveTemporarily(board: Board, move: Move): Board {
  const next = cloneBoard(board);
  const { from, to, piece, promotion, isCastling, isEnPassant } = move;

  next[from.row][from.col] = null;

  if (promotion) {
    next[to.row][to.col] = { type: promotion, color: piece.color };
  } else {
    next[to.row][to.col] = { ...piece };
  }

  if (isEnPassant) {
    // The captured pawn sits on the same rank as 'from', but 'to' col
    next[from.row][to.col] = null;
  }

  if (isCastling === 'kingside') {
    // Move rook from col 7 to col 5
    next[from.row][5] = next[from.row][7];
    next[from.row][7] = null;
  } else if (isCastling === 'queenside') {
    // Move rook from col 0 to col 3
    next[from.row][3] = next[from.row][0];
    next[from.row][0] = null;
  }

  return next;
}

// Get all strictly legal moves for a piece
export function getLegalMovesForSquare(
  board: Board,
  square: SquareCoord,
  castling: CastlingRights,
  enPassantTarget: SquareCoord | null
): Move[] {
  const piece = board[square.row][square.col];
  if (!piece) return [];

  const pseudoMoves = getPseudoLegalMoves(board, square, castling, enPassantTarget);
  return pseudoMoves.filter(move => {
    const nextBoard = applyMoveTemporarily(board, move);
    return !isKingInCheck(nextBoard, piece.color);
  });
}

// Get all legal moves for a player
export function getAllLegalMoves(
  board: Board,
  color: PieceColor,
  castling: CastlingRights,
  enPassantTarget: SquareCoord | null
): Move[] {
  const allMoves: Move[] = [];
  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const piece = board[r][c];
      if (piece && piece.color === color) {
        const moves = getLegalMovesForSquare(board, { row: r, col: c }, castling, enPassantTarget);
        allMoves.push(...moves);
      }
    }
  }
  return allMoves;
}

export function formatMoveSAN(
  boardBefore: Board,
  move: Move,
  isCheck: boolean,
  isCheckmate: boolean
): string {
  if (move.isCastling === 'kingside') {
    return isCheckmate ? 'O-O#' : isCheck ? 'O-O+' : 'O-O';
  }
  if (move.isCastling === 'queenside') {
    return isCheckmate ? 'O-O-O#' : isCheck ? 'O-O-O+' : 'O-O-O';
  }

  const piece = move.piece;
  const toSquare = coordToAlgebraic(move.to);
  const fromSquare = coordToAlgebraic(move.from);
  let san = '';

  if (piece.type === 'p') {
    if (move.captured || move.isEnPassant) {
      san = `${fromSquare[0]}x${toSquare}`;
    } else {
      san = toSquare;
    }
    if (move.promotion) {
      san += `=${move.promotion.toUpperCase()}`;
    }
  } else {
    san = piece.type.toUpperCase();
    if (move.captured) {
      san += `x${toSquare}`;
    } else {
      san += toSquare;
    }
  }

  if (isCheckmate) {
    san += '#';
  } else if (isCheck) {
    san += '+';
  }

  return san;
}

export function getBoardPositionHash(
  board: Board,
  turn: PieceColor,
  castling: CastlingRights,
  enPassantTarget: SquareCoord | null
): string {
  let str = '';
  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const p = board[r][c];
      if (!p) str += '.';
      else str += p.color === 'w' ? p.type.toUpperCase() : p.type;
    }
  }
  str += `_${turn}_`;
  str += `${castling.wK ? 'K' : ''}${castling.wQ ? 'Q' : ''}${castling.bK ? 'k' : ''}${castling.bQ ? 'q' : ''}_`;
  str += enPassantTarget ? `${enPassantTarget.row},${enPassantTarget.col}` : '-';
  return str;
}

export function makeMove(state: GameState, move: Move): GameState {
  const { board, turn, castling, history, capturedPieces, positionHistory } = state;
  const { from, to, piece, promotion, isCastling, isEnPassant, captured } = move;

  const nextBoard = cloneBoard(board);
  const nextCastling: CastlingRights = { ...castling };
  const nextCaptured = {
    w: [...capturedPieces.w],
    b: [...capturedPieces.b],
  };

  let actualCaptured: Piece | null = captured || null;

  // Clear source square
  nextBoard[from.row][from.col] = null;

  // Handle en passant capture
  if (isEnPassant) {
    actualCaptured = nextBoard[from.row][to.col];
    nextBoard[from.row][to.col] = null;
  }

  // Handle normal capture
  if (actualCaptured) {
    if (turn === 'w') {
      nextCaptured.w.push(actualCaptured);
    } else {
      nextCaptured.b.push(actualCaptured);
    }
  }

  // Place moving piece
  if (promotion) {
    nextBoard[to.row][to.col] = { type: promotion, color: piece.color };
  } else {
    nextBoard[to.row][to.col] = { ...piece };
  }

  // Handle castling rook movement
  if (isCastling === 'kingside') {
    nextBoard[from.row][5] = nextBoard[from.row][7];
    nextBoard[from.row][7] = null;
  } else if (isCastling === 'queenside') {
    nextBoard[from.row][3] = nextBoard[from.row][0];
    nextBoard[from.row][0] = null;
  }

  // Update castling rights if King or Rooks move
  if (piece.type === 'k') {
    if (turn === 'w') {
      nextCastling.wK = false;
      nextCastling.wQ = false;
    } else {
      nextCastling.bK = false;
      nextCastling.bQ = false;
    }
  } else if (piece.type === 'r') {
    if (turn === 'w') {
      if (from.row === 7 && from.col === 0) nextCastling.wQ = false;
      if (from.row === 7 && from.col === 7) nextCastling.wK = false;
    } else {
      if (from.row === 0 && from.col === 0) nextCastling.bQ = false;
      if (from.row === 0 && from.col === 7) nextCastling.bK = false;
    }
  }

  // If opponent rook is captured in corner, revoke corresponding rights
  if (actualCaptured && actualCaptured.type === 'r') {
    if (to.row === 7 && to.col === 0) nextCastling.wQ = false;
    if (to.row === 7 && to.col === 7) nextCastling.wK = false;
    if (to.row === 0 && to.col === 0) nextCastling.bQ = false;
    if (to.row === 0 && to.col === 7) nextCastling.bK = false;
  }

  // Determine new en passant target
  let nextEnPassantTarget: SquareCoord | null = null;
  if (piece.type === 'p' && Math.abs(to.row - from.row) === 2) {
    nextEnPassantTarget = {
      row: (from.row + to.row) / 2,
      col: from.col,
    };
  }

  // Update 50-move clock
  let nextHalfmoveClock = state.halfmoveClock + 1;
  if (piece.type === 'p' || actualCaptured) {
    nextHalfmoveClock = 0;
  }

  const nextTurn: PieceColor = turn === 'w' ? 'b' : 'w';
  const nextFullmoveNumber = turn === 'b' ? state.fullmoveNumber + 1 : state.fullmoveNumber;

  // Check condition for the new turn
  const isOpponentInCheck = isKingInCheck(nextBoard, nextTurn);
  const opponentLegalMoves = getAllLegalMoves(nextBoard, nextTurn, nextCastling, nextEnPassantTarget);

  let isCheckmate = false;
  let isStalemate = false;
  let isGameOver = false;
  let winner: PieceColor | 'draw' | null = null;

  if (opponentLegalMoves.length === 0) {
    isGameOver = true;
    if (isOpponentInCheck) {
      isCheckmate = true;
      winner = turn; // Current mover delivered checkmate
    } else {
      isStalemate = true;
      winner = 'draw';
    }
  }

  // 50-move rule
  const isDrawFiftyMoves = nextHalfmoveClock >= 100;
  if (isDrawFiftyMoves && !isGameOver) {
    isGameOver = true;
    winner = 'draw';
  }

  // Threefold repetition
  const posHash = getBoardPositionHash(nextBoard, nextTurn, nextCastling, nextEnPassantTarget);
  const nextPositionHistory = [...positionHistory, posHash];
  const occurrences = nextPositionHistory.filter(h => h === posHash).length;
  const isDrawRepetition = occurrences >= 3;
  if (isDrawRepetition && !isGameOver) {
    isGameOver = true;
    winner = 'draw';
  }

  // Insufficient Material
  const isDrawInsufficientMaterial = isInsufficientMaterial(nextBoard);
  if (isDrawInsufficientMaterial && !isGameOver) {
    isGameOver = true;
    winner = 'draw';
  }

  // Format SAN with check/checkmate symbol
  const san = formatMoveSAN(board, { ...move, captured: actualCaptured }, isOpponentInCheck, isCheckmate);
  const recordedMove: Move = {
    ...move,
    captured: actualCaptured,
    san,
  };

  return {
    board: nextBoard,
    turn: nextTurn,
    castling: nextCastling,
    enPassantTarget: nextEnPassantTarget,
    halfmoveClock: nextHalfmoveClock,
    fullmoveNumber: nextFullmoveNumber,
    history: [...history, recordedMove],
    isCheck: isOpponentInCheck,
    isCheckmate,
    isStalemate,
    isDrawFiftyMoves,
    isDrawRepetition,
    isDrawInsufficientMaterial,
    isGameOver,
    isResigned: false,
    resignedBy: null,
    winner,
    capturedPieces: nextCaptured,
    positionHistory: nextPositionHistory,
  };
}

export function isInsufficientMaterial(board: Board): boolean {
  const pieces: { type: PieceType; color: PieceColor; row: number; col: number }[] = [];

  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const p = board[r][c];
      if (p) {
        pieces.push({ type: p.type, color: p.color, row: r, col: c });
      }
    }
  }

  // If there are pawns, rooks, or queens, checkmate is still possible
  if (pieces.some(p => p.type === 'p' || p.type === 'r' || p.type === 'q')) {
    return false;
  }

  const whitePieces = pieces.filter(p => p.color === 'w');
  const blackPieces = pieces.filter(p => p.color === 'b');

  // K vs K
  if (whitePieces.length === 1 && blackPieces.length === 1) {
    return true;
  }

  // K+N vs K or K vs K+N
  if (
    (whitePieces.length === 2 && whitePieces.some(p => p.type === 'n') && blackPieces.length === 1) ||
    (blackPieces.length === 2 && blackPieces.some(p => p.type === 'n') && whitePieces.length === 1)
  ) {
    return true;
  }

  // K+B vs K or K vs K+B
  if (
    (whitePieces.length === 2 && whitePieces.some(p => p.type === 'b') && blackPieces.length === 1) ||
    (blackPieces.length === 2 && blackPieces.some(p => p.type === 'b') && whitePieces.length === 1)
  ) {
    return true;
  }

  // K+B vs K+B where both bishops are on the same square color
  if (
    whitePieces.length === 2 &&
    whitePieces.some(p => p.type === 'b') &&
    blackPieces.length === 2 &&
    blackPieces.some(p => p.type === 'b')
  ) {
    const whiteBishop = whitePieces.find(p => p.type === 'b')!;
    const blackBishop = blackPieces.find(p => p.type === 'b')!;
    const whiteColor = (whiteBishop.row + whiteBishop.col) % 2;
    const blackColor = (blackBishop.row + blackBishop.col) % 2;
    if (whiteColor === blackColor) {
      return true;
    }
  }

  return false;
}

export function calculateMaterialAdvantage(capturedPieces: { w: Piece[]; b: Piece[] }): {
  whiteDiff: number; // Positive means white is ahead in material
  blackDiff: number;
} {
  const pieceValues: Record<PieceType, number> = {
    p: 1,
    n: 3,
    b: 3,
    r: 5,
    q: 9,
    k: 0,
  };

  // Captured by White = Black pieces lost
  const whiteScore = capturedPieces.w.reduce((acc, p) => acc + (pieceValues[p.type] || 0), 0);
  // Captured by Black = White pieces lost
  const blackScore = capturedPieces.b.reduce((acc, p) => acc + (pieceValues[p.type] || 0), 0);

  const diff = whiteScore - blackScore;
  return {
    whiteDiff: diff > 0 ? diff : 0,
    blackDiff: diff < 0 ? Math.abs(diff) : 0,
  };
}

export function exportToPGN(gameState: GameState): string {
  const date = new Date().toISOString().split('T')[0].replace(/-/g, '.');
  let pgn = `[Event "Catur Klasik Pro Tournament"]\n`;
  pgn += `[Site "Local Club Room"]\n`;
  pgn += `[Date "${date}"]\n`;
  pgn += `[Round "1"]\n`;
  pgn += `[White "Pemain Putih"]\n`;
  pgn += `[Black "AI / Komputer"]\n`;

  let result = '*';
  if (gameState.winner === 'w') result = '1-0';
  else if (gameState.winner === 'b') result = '0-1';
  else if (gameState.winner === 'draw') result = '1/2-1/2';

  pgn += `[Result "${result}"]\n\n`;

  let moveStr = '';
  gameState.history.forEach((m, idx) => {
    if (idx % 2 === 0) {
      const moveNum = Math.floor(idx / 2) + 1;
      moveStr += `${moveNum}. ${m.san} `;
    } else {
      moveStr += `${m.san} `;
    }
  });

  moveStr += result;
  return pgn + moveStr.trim();
}
